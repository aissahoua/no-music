if (-not (Test-Path ".venv")) {
    Write-Host "Virtual environment not found." -ForegroundColor Red
    Write-Host "Please run 'install.ps1' first."
    Pause
    exit
}

Write-Host "Starting No Music Server..." -ForegroundColor Cyan
& .venv\Scripts\python.exe -m server.app
Pause
