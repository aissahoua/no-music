import contextlib
import json
import re
import sys
import time
from typing import Dict, Tuple

from .db import update_job, is_job_cancelled

THROTTLE_PCT_DELTA = 2
THROTTLE_INTERVAL_S = 0.5
_progress_cache: Dict[Tuple[int, str], Dict[str, float]] = {}


def update_job_progress_throttled(job_id: int, phase: str, pct: int) -> None:
    try:
        key = (job_id, phase)
        now = time.time()
        cached = _progress_cache.get(key, {'t': 0.0, 'pct': -1})
        pct = max(0, min(100, int(pct)))
        should_write = False
        if cached['pct'] < 0:
            should_write = True
        elif abs(pct - cached['pct']) >= THROTTLE_PCT_DELTA:
            should_write = True
        elif (now - cached['t']) >= THROTTLE_INTERVAL_S:
            should_write = True
        if should_write:
            payload = json.dumps({"phase": phase, "progress": pct})
            update_job(job_id, phase, message=payload, percent=pct, phase=phase)
            _progress_cache[key] = {'t': now, 'pct': pct}
    except Exception:
        pass


@contextlib.contextmanager
def capture_percent_progress(job_id: int, phase: str):
    pat1 = re.compile(r'(\d{1,3})%\|')
    pat2 = re.compile(r'(\d{1,3})%')

    class _Writer:
        def __init__(self, stream):
            self.stream = stream

        def write(self, data):
            try:
                self.stream.write(data)
            except Exception:
                pass
            try:
                # Check cancellation periodically during output
                if job_id and is_job_cancelled(job_id):
                    raise RuntimeError(f"Job {job_id} cancelled by user")

                match = pat1.search(data) or pat2.search(data)
                if match:
                    pct = int(match.group(1))
                    update_job_progress_throttled(job_id, phase, pct)
            except RuntimeError:
                raise  # Propagate cancellation
            except Exception:
                pass

        def flush(self):
            try:
                self.stream.flush()
            except Exception:
                pass

    original_stdout, original_stderr = sys.stdout, sys.stderr
    if job_id:
        sys.stdout, sys.stderr = _Writer(original_stdout), _Writer(original_stderr)
    try:
        yield
    finally:
        sys.stdout, sys.stderr = original_stdout, original_stderr
