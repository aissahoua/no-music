import json
import os
from typing import Dict, List

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(BASE_DIR, 'config.json')
DEFAULT_MODEL = 'UVR-MDX-NET-Inst_HQ_3'

MODEL_ALIASES = {
    'htdemucs': 'htdemucs.yaml',
    'htdemucs_ft': 'htdemucs_ft.yaml',
    'hdemucs_mmi': 'hdemucs_mmi.yaml',
    'htdemucs_6s': 'htdemucs_6s.yaml',
    'UVR-MDX-NET-Inst_HQ_3': 'UVR-MDX-NET-Inst_HQ_3.onnx',
    'UVR-MDX-NET-Voc_FT': 'UVR-MDX-NET-Voc_FT.onnx',
    'UVR-MDX-NET-Main': 'UVR_MDXNET_Main.onnx',
}

AVAILABLE_MODELS = [
    {"id": "htdemucs", "label": "Demucs v4 (سريع - جودة ممتازة)"},
    {"id": "htdemucs_ft", "label": "Demucs v4 FT (سريع - محسّن)"},
    {"id": "UVR-MDX-NET-Inst_HQ_3", "label": "HQ 3 (جودة قصوى - بطيء)"},
    {"id": "UVR-MDX-NET-Main", "label": "MDX-NET Main (متوسط - جودة جيدة)"},
    {"id": "UVR-MDX-NET-Voc_FT", "label": "MDX Vocals (خفيف - مخصص للصوت)"},
]


def _default_output_base() -> str:
    userprofile = os.environ.get('USERPROFILE')
    documents = os.path.join(userprofile, 'Documents') if userprofile else os.path.expanduser('~/Documents')
    base = os.path.join(documents, 'no music')
    os.makedirs(base, exist_ok=True)
    return base


# Global state variables
CURRENT_MODE = 'CPU'
OUTPUT_BASE = _default_output_base()
SELECTED_MODEL = DEFAULT_MODEL
MAX_CONCURRENT_JOBS = 1


def load_config() -> Dict:
    """Load configuration from disk, returning defaults if file missing/corrupt."""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as handle:
                return json.load(handle)
    except Exception:
        pass
    return {}


def save_config(cfg: Dict) -> bool:
    """Save configuration to disk."""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as handle:
            json.dump(cfg, handle, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def apply_config_from_disk() -> None:
    """Read config.json and update global state variables."""
    global CURRENT_MODE, OUTPUT_BASE, SELECTED_MODEL, MAX_CONCURRENT_JOBS
    
    cfg = load_config()
    
    # Mode
    mode = cfg.get('mode')
    if mode in ('CPU', 'GPU'):
        CURRENT_MODE = mode
    else:
        # Default to CPU if not set
        CURRENT_MODE = 'CPU'

    # Output Base
    output_base = cfg.get('output_base')
    if output_base:
        OUTPUT_BASE = output_base
    
    ensure_output_structure(OUTPUT_BASE)

    # Model
    selected_model = cfg.get('selected_model')
    if selected_model:
        SELECTED_MODEL = selected_model
    
    # Max Concurrent Jobs
    max_concurrent = cfg.get('max_concurrent_jobs')
    if max_concurrent and isinstance(max_concurrent, int) and max_concurrent > 0:
        MAX_CONCURRENT_JOBS = max_concurrent


def ensure_output_structure(base_path: str) -> None:
    try:
        os.makedirs(os.path.join(base_path, 'صوت'), exist_ok=True)
        os.makedirs(os.path.join(base_path, 'فيديو'), exist_ok=True)
    except Exception:
        pass


def get_audio_output_dir() -> str:
    base = OUTPUT_BASE or _default_output_base()
    audio_dir = os.path.join(base, 'صوت')
    os.makedirs(audio_dir, exist_ok=True)
    return audio_dir


def get_video_output_dir(subfolder: str) -> str:
    base = OUTPUT_BASE or _default_output_base()
    video_dir = os.path.join(base, 'فيديو', subfolder)
    os.makedirs(video_dir, exist_ok=True)
    return video_dir


def resolve_model_id(model_id: str) -> str:
    try:
        if not model_id:
            return MODEL_ALIASES.get(DEFAULT_MODEL)
        if model_id in MODEL_ALIASES:
            return MODEL_ALIASES[model_id]
        if model_id.endswith('.onnx') or model_id.endswith('.yaml'):
            return model_id
        if model_id in ('htdemucs', 'htdemucs_ft', 'hdemucs_mmi', 'htdemucs_6s'):
            return model_id + '.yaml'
        if model_id.startswith('UVR-MDX-NET') or model_id.startswith('UVR_MDXNET'):
            return model_id + '.onnx'
        return model_id
    except Exception:
        return MODEL_ALIASES.get(DEFAULT_MODEL)


def set_mode(mode: str) -> None:
    if mode not in ('CPU', 'GPU'):
        raise ValueError('mode must be CPU or GPU')
    
    cfg = load_config()
    cfg['mode'] = mode
    save_config(cfg)
    
    global CURRENT_MODE
    CURRENT_MODE = mode


def set_output_base(path: str) -> None:
    ensure_output_structure(path)
    cfg = load_config()
    cfg['output_base'] = path
    save_config(cfg)
    
    global OUTPUT_BASE
    OUTPUT_BASE = path


def set_selected_model(model: str) -> None:
    cfg = load_config()
    cfg['selected_model'] = model
    save_config(cfg)
    
    global SELECTED_MODEL
    SELECTED_MODEL = model


def set_max_concurrent_jobs(count: int) -> None:
    if not isinstance(count, int) or count < 1:
        raise ValueError('max_concurrent_jobs must be a positive integer')
    
    cfg = load_config()
    cfg['max_concurrent_jobs'] = count
    save_config(cfg)
    
    global MAX_CONCURRENT_JOBS
    MAX_CONCURRENT_JOBS = count


def get_config_payload() -> Dict:
    return {
        'mode': CURRENT_MODE,
        'output_base': OUTPUT_BASE,
        'selected_model': SELECTED_MODEL,
        'max_concurrent_jobs': MAX_CONCURRENT_JOBS
    }


def get_allowed_download_dirs() -> List[str]:
    userprofile = os.environ.get('USERPROFILE', '')
    docs = os.path.join(userprofile, 'Documents') if userprofile else os.path.expanduser('~/Documents')
    return [
        os.path.join(docs, 'مزيل الموسيقى'),
        os.path.join(os.path.expanduser('~'), 'Documents', 'مزيل الموسيقى'),
        OUTPUT_BASE,
    ]


# Initialize on import
apply_config_from_disk()
