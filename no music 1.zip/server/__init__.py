"""
Server package for the no-music application.
"""
