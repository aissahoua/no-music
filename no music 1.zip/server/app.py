import json
import mimetypes
import os
import shutil
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from flask import Flask, jsonify, request, send_file

from . import config as cfg
from .config import (
    AVAILABLE_MODELS,
    SELECTED_MODEL,
    CURRENT_MODE,
    MAX_CONCURRENT_JOBS,
    get_allowed_download_dirs,
    get_config_payload,
    set_mode,
    set_output_base,
    set_selected_model,
    set_max_concurrent_jobs,
)
from .db import (
    add_step,
    delete_job,
    fetch_job_files,
    fetch_job_status,
    fetch_job_steps,
    fetch_processed_videos,
    fetch_recent_jobs,
    find_processed_audio,
    get_job,
    get_job_audio_path,
    init_db_if_needed,
    is_job_cancelled,
    start_job,
    update_job,
    update_step,
    mark_incomplete_jobs_as_failed,
)
from .media import (
    AUDIO_SEPARATOR_AVAILABLE,
    download_youtube_audio,
    download_youtube_media,
    get_youtube_formats,
    install_addons,
    install_cpu_libs,
    remove_music_from_media,
    reset_global_separator,
    sanitize_filename,
)

app = Flask(__name__)

# Global executor - needs to be recreated when max_workers changes
_executor_lock = threading.Lock()
executor = ThreadPoolExecutor(max_workers=MAX_CONCURRENT_JOBS)

def get_executor():
    """Get the current executor instance"""
    global executor
    return executor

def restart_executor(new_max_workers):
    """Restart executor with new worker count"""
    global executor
    with _executor_lock:
        old_executor = executor
        executor = ThreadPoolExecutor(max_workers=new_max_workers)
        # Shutdown old executor without waiting for tasks
        old_executor.shutdown(wait=False)


@app.after_request
def apply_cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    response.headers['Access-Control-Expose-Headers'] = 'Content-Disposition'
    return response


@app.route('/')
def index():
    return send_file(os.path.join(cfg.BASE_DIR, 'web_interface.html'))


@app.route('/icon.png')
def icon():
    return send_file(os.path.join(cfg.BASE_DIR, 'icon.png'))


@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'audio_separator_available': AUDIO_SEPARATOR_AVAILABLE,
        'mode': cfg.CURRENT_MODE,
        'timestamp': datetime.utcnow().isoformat(),
    })


@app.route('/processed_videos', methods=['GET'])
def processed_videos():
    try:
        return jsonify({'videos': fetch_processed_videos()})
    except Exception as exc:
        return jsonify({'error': f'Failed to get processed videos: {exc}'}), 500


def _process_youtube_audio_task(job_id: int, youtube_url: str):
    # Update status to started immediately when task begins execution
    update_job(job_id, 'started', phase='started', percent=0)
    
    job_temp_dir = tempfile.mkdtemp(prefix=f"mr_{job_id}_")
    try:
        audio_path, title = download_youtube_audio(youtube_url, job_id, temp_dir_path=job_temp_dir)
        update_job(job_id, 'downloaded', message=json.dumps({'phase': 'downloading', 'progress': 100}),
                   percent=100, phase='downloading')

        if is_job_cancelled(job_id):
            update_job(job_id, 'cancelled')
            return

        clean_audio_path, _ = remove_music_from_media(audio_path, title, job_id, temp_dir_path=job_temp_dir)
        update_job(job_id, 'done', output_audio_path=clean_audio_path, output_video_path=None,
                   message=json.dumps({'phase': 'done', 'progress': 100}), percent=100, phase='done')
    except Exception as exc:
        if 'cancelled' in str(exc).lower():
            update_job(job_id, 'cancelled', message='Cancelled by user')
        else:
            update_job(job_id, 'error', message=json.dumps({'phase': 'error', 'progress': 100}), error_text=str(exc))
    finally:
        shutil.rmtree(job_temp_dir, ignore_errors=True)


@app.route('/process_youtube', methods=['POST'])
def process_youtube_audio():
    data = request.get_json() or {}
    youtube_url = (data.get('url') or '').strip()
    if not youtube_url:
        return jsonify({'error': "Missing 'url' in request body"}), 400

    # Check if already processed
    existing = find_processed_audio(youtube_url, quality='audio')
    if existing:
        return jsonify({
            'status': 'exists',
            'job_id': existing['job_id'],
            'message': 'Audio already processed'
        })

    job_id = start_job('api', source_url=youtube_url, quality='audio')
    update_job(job_id, 'started')
    
    executor.submit(_process_youtube_audio_task, job_id, youtube_url)

    return jsonify({
        'status': 'queued',
        'job_id': job_id,
        'message': 'Job queued successfully',
        'job_details': get_job(job_id)
    })


@app.route('/youtube_formats', methods=['POST'])
def youtube_formats():
    data = request.get_json() or {}
    url = (data.get('url') or '').strip()
    if not url:
        return jsonify({'error': 'Missing url'}), 400
    try:
        title, qualities = get_youtube_formats(url)
        return jsonify({'title': title, 'qualities': qualities})
    except Exception as exc:
        return jsonify({'error': f'Failed to fetch formats: {exc}'}), 500


def _process_youtube_video_task(job_id: int, url: str, quality: str):
    # Update status to started immediately when task begins execution
    update_job(job_id, 'started', phase='started', percent=0)

    job_temp_dir = tempfile.mkdtemp(prefix=f"mr_{job_id}_")
    try:
        media_path, title = download_youtube_media(url, job_id, quality=quality, temp_dir_path=job_temp_dir)
        update_job(job_id, 'downloaded', message=json.dumps({'phase': 'downloading', 'progress': 100, 'title': title}),
                   percent=100, phase='downloading')

        clean_audio_path, output_video_path = remove_music_from_media(media_path, title, job_id,
                                                                      temp_dir_path=job_temp_dir)
        update_job(job_id, 'done', output_audio_path=clean_audio_path, output_video_path=output_video_path,
                   message=json.dumps({'phase': 'done', 'progress': 100}), percent=100, phase='done')
    except Exception as exc:
        if 'cancelled' in str(exc).lower():
            update_job(job_id, 'cancelled', message='Cancelled by user')
        else:
            update_job(job_id, 'error', message=json.dumps({'phase': 'error', 'progress': 100}), error_text=str(exc))
    finally:
        shutil.rmtree(job_temp_dir, ignore_errors=True)


@app.route('/process_youtube_vid', methods=['POST'])
def process_youtube_video():
    data = request.get_json() or {}
    url = (data.get('url') or '').strip()
    quality = data.get('quality', 'auto')
    if not url:
        return jsonify({'error': "Missing 'url' in request body"}), 400

    # Check if already processed
    existing = find_processed_audio(url, quality=quality)
    if existing:
        return jsonify({
            'status': 'exists',
            'job_id': existing['job_id'],
            'message': 'Video already processed'
        })

    job_id = start_job('api_video', source_url=url, quality=quality)
    update_job(job_id, 'started')
    
    executor.submit(_process_youtube_video_task, job_id, url, quality)

    return jsonify({
        'status': 'queued',
        'job_id': job_id,
        'message': 'Job queued successfully',
        'job_details': get_job(job_id)
    })


def _process_file_task(job_id: int, temp_path: str, safe_name: str, job_temp_dir: str):
    # Update status to started immediately when task begins execution
    update_job(job_id, 'started', phase='started', percent=0)

    try:
        add_step(job_id, 'uploaded', status='done')
        update_job(job_id, 'downloaded', message=f"Uploaded: {safe_name}", percent=100, phase='downloading')

        if is_job_cancelled(job_id):
            update_job(job_id, 'cancelled')
            return

        title = os.path.splitext(safe_name)[0]
        clean_audio_path, output_video_path = remove_music_from_media(temp_path, title, job_id,
                                                                      temp_dir_path=job_temp_dir)
        update_job(job_id, 'done', output_audio_path=clean_audio_path, output_video_path=output_video_path,
                   message=json.dumps({'phase': 'done', 'progress': 100}), percent=100, phase='done')
    except Exception as exc:
        if 'cancelled' in str(exc).lower():
            update_job(job_id, 'cancelled', message='Cancelled by user')
        else:
            update_job(job_id, 'error', message=json.dumps({'phase': 'error', 'progress': 100}), error_text=str(exc))
    finally:
        shutil.rmtree(job_temp_dir, ignore_errors=True)


@app.route('/process_file', methods=['POST'])
def process_uploaded_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if not file.filename:
        return jsonify({'error': 'No selected file'}), 400

    job_id = start_job('upload', input_path=file.filename)
    update_job(job_id, 'started')
    
    # We need to save the file synchronously before offloading processing
    job_temp_dir = tempfile.mkdtemp(prefix=f"mr_{job_id}_")
    try:
        safe_name = sanitize_filename(file.filename)
        temp_path = os.path.join(job_temp_dir, safe_name)
        file.save(temp_path)
        
        executor.submit(_process_file_task, job_id, temp_path, safe_name, job_temp_dir)
        
        return jsonify({
            'status': 'queued',
            'job_id': job_id,
            'message': 'File uploaded and job queued',
            'job_details': get_job(job_id)
        })
    except Exception as exc:
        shutil.rmtree(job_temp_dir, ignore_errors=True)
        return jsonify({'error': f'Failed to save file: {exc}'}), 500


@app.route('/download/<path:file_path>', methods=['GET'])
def download_file(file_path):
    abs_path = os.path.abspath(file_path)
    allowed_dirs = [os.path.abspath(path) for path in get_allowed_download_dirs() if path]
    if not any(abs_path.startswith(directory) for directory in allowed_dirs):
        return jsonify({'error': 'File access not allowed'}), 403
    if not os.path.exists(abs_path):
        return jsonify({'error': 'File not found'}), 404
    mimetype, _ = mimetypes.guess_type(abs_path)
    return send_file(abs_path, as_attachment=False, mimetype=mimetype or 'application/octet-stream')


@app.route('/jobs', methods=['GET'])
def list_jobs():
    try:
        return jsonify(fetch_recent_jobs())
    except Exception as exc:
        return jsonify({'error': f'Failed to list jobs: {exc}'}), 500


@app.route('/job_steps/<int:job_id>', methods=['GET'])
def job_steps(job_id):
    try:
        return jsonify(fetch_job_steps(job_id))
    except Exception as exc:
        return jsonify({'error': f'Failed to list steps: {exc}'}), 500


@app.route('/get_mode', methods=['GET'])
def get_mode():
    return jsonify({'mode': cfg.CURRENT_MODE})


@app.route('/set_mode', methods=['POST'])
def set_mode_route():
    data = request.get_json() or {}
    mode = data.get('mode')
    if mode not in ('CPU', 'GPU'):
        return jsonify({'error': 'mode must be CPU or GPU'}), 400
    try:
        set_mode(mode)
        reset_global_separator()
        return jsonify({'status': 'ok', 'mode': mode, 'restart_required': True})
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/models', methods=['GET'])
def list_models():
    return jsonify({'models': AVAILABLE_MODELS, 'selected_model': cfg.SELECTED_MODEL})


@app.route('/config', methods=['GET'])
def get_config():
    payload = get_config_payload()
    payload['audio_separator_available'] = AUDIO_SEPARATOR_AVAILABLE
    return jsonify(payload)


@app.route('/config', methods=['POST'])
def set_config():
    global executor
    data = request.get_json() or {}
    resp = {'status': 'ok'}
    try:
        if 'mode' in data:
            set_mode(data['mode'])
            resp['restart_required'] = True
        if 'output_base' in data and data['output_base']:
            set_output_base(data['output_base'])
        if 'selected_model' in data and data['selected_model']:
            set_selected_model(data['selected_model'])
        if 'max_concurrent_jobs' in data:
            new_count = int(data['max_concurrent_jobs'])
            set_max_concurrent_jobs(new_count)
            # Restart executor with new worker count
            restart_executor(new_count)
            resp['executor_restarted'] = True
        reset_global_separator()
        payload = get_config_payload()
        resp.update({
            'mode': payload.get('mode'),
            'output_base': payload.get('output_base'),
            'selected_model': payload.get('selected_model'),
            'max_concurrent_jobs': payload.get('max_concurrent_jobs'),
        })
        return jsonify(resp)
    except Exception as exc:
        return jsonify({'error': str(exc)}), 500


@app.route('/install_addons', methods=['POST'])
def install_addons_route():
    ok, message = install_addons()
    status = 200 if ok else 500
    return jsonify({'status': 'ok' if ok else 'error', 'message': message}), status


@app.route('/install_cpu_libs', methods=['POST'])
def install_cpu_libs_route():
    ok, message = install_cpu_libs()
    status = 200 if ok else 500
    return jsonify({'status': 'ok' if ok else 'error', 'message': message,
                    'audio_separator_available': AUDIO_SEPARATOR_AVAILABLE}), status


@app.route('/cancel_job', methods=['POST'])
def cancel_job():
    data = request.get_json() or {}
    job_id = int(data.get('job_id', 0))
    update_job(job_id, 'cancelled', message='User cancelled')
    return jsonify({'status': 'ok'})


@app.route('/delete_job', methods=['POST'])
def delete_job_route():
    data = request.get_json() or {}
    job_id = int(data.get('job_id', 0))
    delete_files = bool(data.get('delete_files', False))
    delete_job(job_id, delete_files=delete_files)
    return jsonify({'status': 'ok'})


@app.route('/retry_job', methods=['POST'])
def retry_job():
    """Retry a failed or cancelled job"""
    data = request.get_json() or {}
    job_id = int(data.get('job_id', 0))
    
    if not job_id:
        return jsonify({'error': 'Missing job_id'}), 400
    
    # Get job details
    job_status = fetch_job_status(job_id)
    if not job_status:
        return jsonify({'error': 'Job not found'}), 404
    
    # Only allow retry for failed, cancelled, or error jobs
    if job_status['status'] not in ('error', 'cancelled', 'failed'):
        return jsonify({'error': 'Job is not in a retryable state'}), 400
    
    source_type = job_status.get('source_type')
    source_url = job_status.get('source_url')
    
    # Reset job status to queued
    update_job(job_id, 'queued', message='Retrying job', percent=0, phase='queued')
    
    # Re-submit based on source type using a direct Thread to bypass potential executor congestion
    if source_type == 'api':
        # YouTube audio
        threading.Thread(target=_process_youtube_audio_task, args=(job_id, source_url)).start()
    elif source_type == 'api_video':
        # YouTube video
        quality = job_status.get('quality', 'best')
        threading.Thread(target=_process_youtube_video_task, args=(job_id, source_url, quality)).start()
    elif source_type == 'upload':
        # File upload - cannot retry as file is gone
        return jsonify({'error': 'Cannot retry uploaded files'}), 400
    elif source_type == 'extension':
        # Extension video
        threading.Thread(target=_process_youtube_video_task, args=(job_id, source_url, 'best')).start()
    else:
        return jsonify({'error': 'Unknown source type'}), 400
    
    return jsonify({
        'status': 'ok',
        'message': 'Job queued for retry',
        'job_id': job_id
    })


@app.route('/job_files/<int:job_id>', methods=['GET'])
def job_files(job_id):
    files = fetch_job_files(job_id)
    if not files:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(files)


@app.route('/open_in_explorer', methods=['POST'])
def open_in_explorer():
    data = request.get_json() or {}
    path = data.get('path')
    if not path:
        return jsonify({'error': 'Missing path'}), 400
    folder = os.path.dirname(path)
    if os.path.exists(folder):
        try:
            os.startfile(folder)
        except Exception:
            pass
        return jsonify({'status': 'ok'})
    return jsonify({'error': 'Folder not found'}), 404


def _process_video_extension_task(job_id: int, video_url: str):
    job_temp_dir = tempfile.mkdtemp(prefix=f"mr_{job_id}_")
    try:
        audio_file, title = download_youtube_audio(video_url, job_id, temp_dir_path=job_temp_dir)
        update_job(job_id, 'downloaded', message=f"Downloaded: {title}", percent=100, phase='downloading')

        if is_job_cancelled(job_id):
            update_job(job_id, 'cancelled')
            return

        clean_audio_path, _ = remove_music_from_media(audio_file, title, job_id, temp_dir_path=job_temp_dir)
        update_job(job_id, 'done', output_audio_path=clean_audio_path, output_video_path=None,
                   message=json.dumps({'phase': 'done', 'progress': 100}), percent=100, phase='done')
    except Exception as exc:
        update_job(job_id, 'error', message=json.dumps({'phase': 'error', 'progress': 100}), error_text=str(exc))
    finally:
        shutil.rmtree(job_temp_dir, ignore_errors=True)


@app.route('/process_video', methods=['POST', 'OPTIONS'])
def process_video():
    if request.method == 'OPTIONS':
        return jsonify({'status': 'ok'})

    data = request.get_json() or {}
    video_url = (data.get('url') or '').strip()
    if not video_url:
        return jsonify({'error': 'Missing video URL'}), 400
    if not video_url.startswith('https://www.youtube.com/watch'):
        return jsonify({'error': 'Invalid YouTube URL'}), 400

    job_id = start_job('extension', source_url=video_url)
    update_job(job_id, 'started')

    executor.submit(_process_video_extension_task, job_id, video_url)

    return jsonify({
        'status': 'success',
        'job_id': job_id,
        'message': 'تم بدء معالجة الفيديو بنجاح',
        'audio_url': f"http://localhost:5000/download_audio/{job_id}"
    })


@app.route('/job_status/<job_id>', methods=['GET'])
def get_job_status(job_id):
    status = fetch_job_status(int(job_id))
    if not status:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify(status)


@app.route('/download_audio/<job_id>', methods=['GET'])
def download_audio(job_id):
    path = get_job_audio_path(int(job_id))
    if not path or not os.path.exists(path):
        return jsonify({'error': 'Audio file not found'}), 404
    
    # Enable Range requests (seeking) and inline playback
    response = send_file(path, as_attachment=False, conditional=True)
    
    # Smart Caching: Cache for 1 year since job IDs/files are immutable
    response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
    
    return response


@app.route('/check_processed', methods=['POST'])
def check_processed():
    data = request.get_json() or {}
    url = (data.get('url') or '').strip()
    if not url:
        return jsonify({'error': 'Missing url'}), 400
    result = find_processed_audio(url)
    if result and result.get('output_audio_path') and os.path.exists(result['output_audio_path']):
        return jsonify({
            'found': True,
            'job_id': result['job_id'],
            'audio_url': f"http://localhost:5000/download_audio/{result['job_id']}"
        })
    return jsonify({'found': False})


if __name__ == '__main__':
    print('Starting no music API Server...')
    init_db_if_needed()
    mark_incomplete_jobs_as_failed()
    print('Web interface available at: http://localhost:5000')
    print('Health check available at: http://localhost:5000/health')
    print('YouTube processing endpoint: http://localhost:5000/process_youtube')
    print('Local file processing endpoint: http://localhost:5000/process_file')
    print('Job list endpoint: http://localhost:5000/jobs')
    print('Processed videos endpoint: http://localhost:5000/processed_videos')
    app.run(host='0.0.0.0', port=5000, debug=False)
