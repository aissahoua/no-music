import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
from contextlib import nullcontext
from typing import List, Optional, Tuple

import ffmpeg
from yt_dlp import YoutubeDL

from . import config as cfg
from .db import add_step, is_job_cancelled, update_job, update_step
from .progress import capture_percent_progress, update_job_progress_throttled

MODE_SUFFIX = f"{cfg.CURRENT_MODE}separator"
SEPARATOR_BASE_PATH = os.path.join('.venv', MODE_SUFFIX)

try:
    from audio_separator.separator import Separator
    AUDIO_SEPARATOR_AVAILABLE = True
except Exception as exc:
    print(f"Failed to import audio separator: {exc}")
    AUDIO_SEPARATOR_AVAILABLE = False

_temp_dir = tempfile.TemporaryDirectory()


class SeparatorManager:
    _instance = None
    _lock = threading.Lock()
    _separator: Optional['Separator'] = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def get_separator(self, output_dir: str) -> 'Separator':
        if not AUDIO_SEPARATOR_AVAILABLE:
            raise RuntimeError('Audio separator library not available')
        
        with self._lock:
            if self._separator is None:
                self._separator = Separator(
                    output_single_stem='Vocals',
                    output_dir=output_dir,
                    output_format='m4a',
                    output_bitrate='128k',
                    log_formatter=logging.Formatter('%(message)s'),
                )
                self._load_model()
            
            self._separator.output_dir = output_dir
            return self._separator

    def _load_model(self):
        model_id = cfg.resolve_model_id(cfg.SELECTED_MODEL)
        try:
            self._separator.load_model(model_id)
        except Exception:
            fallbacks = ['UVR-MDX-NET-Inst_HQ_3', 'UVR-MDX-NET-Inst_HQ_3.onnx']
            last_err = None
            for candidate in fallbacks:
                try:
                    self._separator.load_model(cfg.resolve_model_id(candidate))
                    print(f"Using fallback separator model: {candidate}")
                    return
                except Exception as err:
                    last_err = err
            raise RuntimeError(f"Failed to load separator model: {last_err}")

    def reset(self):
        with self._lock:
            self._separator = None


def reset_global_separator() -> None:
    SeparatorManager.get_instance().reset()


def sanitize_filename(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]', '', name)
    name = re.sub(r'\s+', ' ', name).strip()
    return name[:120] if len(name) > 120 else name


def has_video_stream(path: str) -> bool:
    try:
        info = ffmpeg.probe(path)
        return any(stream.get('codec_type') == 'video' for stream in info.get('streams', []))
    except Exception:
        try:
            ext = os.path.splitext(path)[1].lower().strip('.')
            return ext in {
                'mp4', 'mkv', 'mov', 'webm', 'avi', 'flv', 'wmv', 'm4v',
                '3gp', '3g2', 'mpg', 'mpeg', 'ts'
            }
        except Exception:
            return False


def _yt_common_opts(output_dir: str) -> Tuple[str, dict]:
    ffmpeg_path = os.path.join(cfg.BASE_DIR, 'ffmpeg.exe')
    return ffmpeg_path, {
        'outtmpl': os.path.join(output_dir, '%(title)s.%(ext)s'),
        'noplaylist': True,
        'quiet': True,
    }


def download_youtube_media(
    url: str,
    job_id: Optional[int] = None,
    quality: Optional[str] = None,
    temp_dir_path: Optional[str] = None,
) -> Tuple[str, str]:
    download_step_id = add_step(job_id, 'downloading') if job_id else None
    if job_id:
        update_job(job_id, 'downloading', message='{"phase":"downloading","progress":0}', percent=0, phase='downloading')

    def hook(payload):
        if payload.get('status') == 'downloading' and job_id:
            downloaded = payload.get('downloaded_bytes') or 0
            total = payload.get('total_bytes') or payload.get('total_bytes_estimate') or 0
            if total:
                pct = int(min(100, max(0, (downloaded / total) * 100)))
                update_job_progress_throttled(job_id, 'downloading', pct)

    output_dir = temp_dir_path or _temp_dir.name
    ffmpeg_path, base_opts = _yt_common_opts(output_dir)
    fmt = 'bestvideo+bestaudio/best'
    if quality:
        quality_str = str(quality)
        if quality_str.isdigit():
            fmt = f'bestvideo[height={int(quality_str)}]+bestaudio/best'
        elif quality_str not in ('auto', ''):
            fmt = quality_str

    opts = {
        **base_opts,
        'format': fmt,
        'merge_output_format': 'mp4',
        'progress_hooks': [hook],
        'ffmpeg_location': ffmpeg_path,
    }
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get('title') or 'video'
        downloaded_path = ydl.prepare_filename(info)

    if download_step_id:
        update_step(download_step_id, 'done')
    if job_id:
        update_job(job_id, 'downloaded', message='{"phase":"downloading","progress":100}', percent=100, phase='downloading')
    return downloaded_path, title


def download_youtube_audio(url: str, job_id: Optional[int] = None, temp_dir_path: Optional[str] = None) -> Tuple[str, str]:
    download_step_id = add_step(job_id, 'downloading') if job_id else None
    if job_id:
        update_job(job_id, 'downloading', message='{"phase":"downloading","progress":0}', percent=0, phase='downloading')

    def hook(payload):
        if payload.get('status') == 'downloading' and job_id:
            downloaded = payload.get('downloaded_bytes') or 0
            total = payload.get('total_bytes') or payload.get('total_bytes_estimate') or 0
            if total:
                pct = int(min(100, max(0, (downloaded / total) * 100)))
                update_job_progress_throttled(job_id, 'downloading', pct)

    output_dir = temp_dir_path or _temp_dir.name
    ffmpeg_path, base_opts = _yt_common_opts(output_dir)
    opts = {
        **base_opts,
        'format': 'bestaudio/best',
        'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'wav'}],
        'progress_hooks': [hook],
        'ffmpeg_location': ffmpeg_path,
    }
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get('title') or 'audio'
        downloaded_path = ydl.prepare_filename(info).rsplit('.', 1)[0] + '.wav'

    if download_step_id:
        update_step(download_step_id, 'done')
    if job_id:
        update_job(job_id, 'downloaded', message='{"phase":"downloading","progress":100}', percent=100, phase='downloading')
    return downloaded_path, title


def get_youtube_formats(url: str) -> Tuple[str, List[dict]]:
    with YoutubeDL({'quiet': True}) as ydl:
        info = ydl.extract_info(url, download=False)
        formats = info.get('formats', [])
        qualities = []
        seen = set()
        for fmt in formats:
            vcodec = fmt.get('vcodec')
            height = fmt.get('height')
            if vcodec and vcodec != 'none' and height and height not in seen:
                qualities.append(
                    {
                        'format_id': fmt.get('format_id'),
                        'ext': fmt.get('ext'),
                        'height': height,
                        'resolution': fmt.get('resolution') or f'{height}p',
                        'fps': fmt.get('fps'),
                        'vcodec': vcodec,
                        'acodec': fmt.get('acodec'),
                        'url': fmt.get('url'),
                    }
                )
                seen.add(height)
        qualities.sort(key=lambda item: item['height'])
        return info.get('title') or 'video', qualities


def remove_music_from_media(
    media_file: str,
    title: str,
    job_id: Optional[int] = None,
    temp_dir_path: Optional[str] = None,
) -> Tuple[str, Optional[str]]:
    if not AUDIO_SEPARATOR_AVAILABLE:
        raise RuntimeError('Audio separator library not available')

    separate_step_id = add_step(job_id, 'separating') if job_id else None
    if job_id:
        update_job(job_id, 'separating', message='{"phase":"separating","progress":0}', percent=0, phase='separating')

    if job_id and is_job_cancelled(job_id):
        update_job(job_id, 'cancelled', message='Cancelled before processing')
        raise RuntimeError('Cancelled')

    job_output_dir = temp_dir_path or _temp_dir.name
    
    # Use the SeparatorManager to get the separator instance
    separator = SeparatorManager.get_instance().get_separator(job_output_dir)
    
    with capture_percent_progress(job_id, 'separating') if job_id else nullcontext():
        output_files = separator.separate(media_file)

    if separate_step_id:
        update_step(separate_step_id, 'done')

    vocals_src = os.path.join(job_output_dir, output_files[0])
    audio_dir = cfg.get_audio_output_dir()
    final_audio_path = os.path.join(audio_dir, sanitize_filename(title) + '_clean.m4a')
    try:
        shutil.move(vocals_src, final_audio_path)
    except Exception:
        shutil.copy2(vocals_src, final_audio_path)

    final_video_path = None
    if has_video_stream(media_file):
        if job_id and is_job_cancelled(job_id):
            update_job(job_id, 'cancelled', message='Cancelled before video mux')
            raise RuntimeError('Cancelled')
        video_dir = cfg.get_video_output_dir(sanitize_filename(title))
        final_video_path = os.path.join(video_dir, sanitize_filename(title) + '_withoutmusic.mp4')
        _mux_video_without_music(media_file, final_audio_path, final_video_path, job_id)

    try:
        if os.path.dirname(media_file) == (temp_dir_path or _temp_dir.name) and os.path.exists(media_file):
            os.remove(media_file)
    except Exception:
        pass
    return final_audio_path, final_video_path


def _mux_video_without_music(media_file: str, audio_path: str, output_video_path: str, job_id: Optional[int]) -> None:
    duration_sec = 0.0
    try:
        duration_sec = float(ffmpeg.probe(media_file).get('format', {}).get('duration') or 0)
    except Exception:
        duration_sec = 0.0

    if job_id:
        update_job(job_id, 'merging', message='{"phase":"merging","progress":0}', phase='merging')

    ffmpeg_bin = 'ffmpeg.exe' if os.name == 'nt' else 'ffmpeg'
    cmd = [
        ffmpeg_bin, '-y',
        '-i', media_file,
        '-i', audio_path,
        '-map', '0:v:0', '-map', '1:a:0',
        '-c:v', 'copy',
        '-c:a', 'copy',
        '-movflags', '+faststart',
        '-progress', 'pipe:1',
        '-loglevel', 'error',
        output_video_path,
    ]

    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
    last_pct = 0
    try:
        while True:
            line = process.stdout.readline()
            if not line:
                if process.poll() is not None:
                    break
                continue
            line = line.strip()
            if line.startswith('out_time_ms='):
                try:
                    out_ms = int(line.split('=', 1)[1])
                    if duration_sec > 0:
                        pct = int(min(100, max(0, (out_ms / 1_000_000.0) / duration_sec * 100)))
                    else:
                        pct = min(99, last_pct + 1)
                    if pct != last_pct and job_id:
                        last_pct = pct
                        update_job_progress_throttled(job_id, 'merging', pct)
                except Exception:
                    pass
            elif line.startswith('progress=') and 'end' in line and job_id:
                update_job(job_id, 'merging', message='{"phase":"merging","progress":100}', percent=100, phase='merging')
        retcode = process.wait()
        if retcode != 0:
            raise RuntimeError(process.stderr.read() or 'ffmpeg mux failed')
    except Exception as err:
        print(f"Video mux failed (stream copy): {err}. Retrying with audio re-encode...")
        process.kill()
        fallback_cmd = [
            ffmpeg_bin, '-y',
            '-i', media_file,
            '-i', audio_path,
            '-map', '0:v:0', '-map', '1:a:0',
            '-c:v', 'copy',
            '-c:a', 'aac', '-b:a', '128k',
            '-movflags', '+faststart',
            '-loglevel', 'error',
            output_video_path,
        ]
        subprocess.run(fallback_cmd, check=True)
    finally:
        try:
            process.stdout.close()
        except Exception:
            pass
        try:
            process.stderr.close()
        except Exception:
            pass


def install_addons() -> Tuple[bool, str]:
    python_bin = os.path.join('.venv', 'Scripts', 'python.exe')
    executable = python_bin if os.path.exists(python_bin) else sys.executable
    try:
        subprocess.check_call([executable, '-m', 'pip', 'install', 'yt-dlp'])
        return True, 'yt-dlp installed'
    except Exception as exc:
        return False, f'Failed to install yt-dlp: {exc}'


def install_cpu_libs() -> Tuple[bool, str]:
    python_bin = os.path.join('.venv', 'Scripts', 'python.exe')
    executable = python_bin if os.path.exists(python_bin) else sys.executable
    target_dir = os.path.join('.venv', 'CPUseparator')
    os.makedirs(target_dir, exist_ok=True)
    commands = [
        ['onnx==1.16.1'],
        ['numpy==1.26.4'],
        ['audio-separator==0.28.5'],
    ]
    try:
        for pkg in commands:
            subprocess.check_call([executable, '-m', 'pip', 'install', *pkg, '-t', target_dir])
        global AUDIO_SEPARATOR_AVAILABLE
        if SEPARATOR_BASE_PATH not in sys.path:
            sys.path.insert(1, SEPARATOR_BASE_PATH)
        AUDIO_SEPARATOR_AVAILABLE = True
        reset_global_separator()
        return True, 'CPU libs installed'
    except Exception as exc:
        AUDIO_SEPARATOR_AVAILABLE = False
        return False, f'Failed to install CPU libs: {exc}'
