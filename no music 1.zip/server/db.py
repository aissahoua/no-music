import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Dict, List, Optional, Generator

from .config import BASE_DIR, get_allowed_download_dirs

DB_PATH = os.path.join(BASE_DIR, 'no_music.db')


@contextmanager
def get_db_cursor(commit: bool = False) -> Generator[sqlite3.Cursor, None, None]:
    """Context manager for database connections and cursors."""
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        yield cur
        if commit:
            conn.commit()
    finally:
        conn.close()


def init_db_if_needed() -> None:
    with get_db_cursor(commit=True) as cur:
        cur.execute(
            '''
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_type TEXT,
                source_url TEXT,
                input_path TEXT,
                output_audio_path TEXT,
                output_video_path TEXT,
                status TEXT,
                message TEXT,
                phase TEXT,
                percent INTEGER,
                created_at TEXT,
                updated_at TEXT,
                finished_at TEXT,
                finished_at TEXT,
                error_text TEXT,
                quality TEXT
            )
            '''
        )
        cur.execute(
            '''
            CREATE TABLE IF NOT EXISTS job_steps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                step_name TEXT,
                status TEXT,
                message TEXT,
                started_at TEXT,
                ended_at TEXT
            )
            '''
        )
        for column, definition in (
            ('phase', 'TEXT'),
            ('percent', 'INTEGER'),
            ('finished_at', 'TEXT'),
            ('finished_at', 'TEXT'),
            ('error_text', 'TEXT'),
            ('quality', 'TEXT'),
        ):
            try:
                cur.execute(f'ALTER TABLE jobs ADD COLUMN {column} {definition}')
            except Exception:
                pass


def start_job(source_type: str, source_url: Optional[str] = None, input_path: Optional[str] = None, quality: Optional[str] = None) -> int:
    with get_db_cursor(commit=True) as cur:
        now = datetime.utcnow().isoformat()
        cur.execute(
            '''INSERT INTO jobs (source_type, source_url, input_path, status, created_at, updated_at, quality)
               VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (source_type, source_url, input_path, 'queued', now, now, quality),
        )
        return cur.lastrowid


def update_job(
    job_id: int,
    status: str,
    message: Optional[str] = None,
    output_audio_path: Optional[str] = None,
    output_video_path: Optional[str] = None,
    percent: Optional[int] = None,
    phase: Optional[str] = None,
    error_text: Optional[str] = None,
) -> None:
    with get_db_cursor(commit=True) as cur:
        now = datetime.utcnow().isoformat()
        finished_at = now if status in ('done', 'error', 'cancelled', 'completed') else None
        cur.execute(
            '''UPDATE jobs SET status=?, message=COALESCE(?, message),
                       output_audio_path=COALESCE(?, output_audio_path),
                       output_video_path=COALESCE(?, output_video_path),
                       phase=COALESCE(?, phase),
                       percent=COALESCE(?, percent),
                       error_text=COALESCE(?, error_text),
                       finished_at=COALESCE(?, finished_at),
                       updated_at=? WHERE id=?''',
            (
                status,
                message,
                output_audio_path,
                output_video_path,
                phase,
                percent,
                error_text,
                finished_at,
                now,
                job_id,
            ),
        )


def add_step(job_id: int, step_name: str, status: str = 'running', message: Optional[str] = None) -> int:
    with get_db_cursor(commit=True) as cur:
        now = datetime.utcnow().isoformat()
        cur.execute(
            '''INSERT INTO job_steps (job_id, step_name, status, message, started_at)
               VALUES (?, ?, ?, ?, ?)''',
            (job_id, step_name, status, message, now),
        )
        return cur.lastrowid


def update_step(step_id: int, status: str, message: Optional[str] = None) -> None:
    with get_db_cursor(commit=True) as cur:
        now = datetime.utcnow().isoformat()
        cur.execute(
            '''UPDATE job_steps SET status=?, message=COALESCE(?, message), ended_at=? WHERE id=?''',
            (status, message, now, step_id),
        )


def _infer_title(row: sqlite3.Row) -> str:
    message = row['message'] or ''
    if 'Downloaded:' in message:
        try:
            return message.split('Downloaded:')[-1].strip()
        except Exception:
            pass
    for path_candidate in (row['output_audio_path'], row['output_video_path'], row['input_path']):
        if path_candidate:
            base = os.path.splitext(os.path.basename(path_candidate))[0]
            if base:
                return base
    if row['source_url']:
        try:
            return row['source_url'].split('v=')[-1][:30]
        except Exception:
            pass
    return row['source_type'] or 'مهمة'


def fetch_recent_jobs(limit: int = 50) -> List[Dict]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        cur.execute(
            '''SELECT id, source_type, source_url, input_path, status, message,
                      phase, percent, created_at, updated_at, output_audio_path,
                      output_video_path, finished_at, error_text
               FROM jobs ORDER BY id DESC LIMIT ?''',
            (limit,),
        )
        rows = cur.fetchall()
        jobs = []
        for row in rows:
            jobs.append(
                {
                    'id': row['id'],
                    'source_type': row['source_type'],
                    'source_url': row['source_url'],
                    'input_path': row['input_path'],
                    'status': row['status'],
                    'message': row['message'],
                    'phase': row['phase'],
                    'percent': row['percent'],
                    'created_at': row['created_at'],
                    'updated_at': row['updated_at'],
                    'output_audio_path': row['output_audio_path'],
                    'output_video_path': row['output_video_path'],
                    'finished_at': row['finished_at'],
                    'error_text': row['error_text'],
                    'title': _infer_title(row),
                }
            )
        return jobs
    finally:
        conn.close()


def fetch_job_steps(job_id: int) -> List[Dict]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        cur.execute(
            '''SELECT id, step_name, status, message, started_at, ended_at
               FROM job_steps WHERE job_id=? ORDER BY id ASC''',
            (job_id,),
        )
        rows = cur.fetchall()
        return [
            {
                'id': row['id'],
                'step_name': row['step_name'],
                'status': row['status'],
                'message': row['message'],
                'started_at': row['started_at'],
                'ended_at': row['ended_at'],
            }
            for row in rows
        ]
    finally:
        conn.close()


def fetch_job_files(job_id: int) -> Optional[Dict]:
    with get_db_cursor() as cur:
        cur.execute('SELECT output_audio_path, output_video_path FROM jobs WHERE id=?', (job_id,))
        row = cur.fetchone()
        if not row:
            return None
        return {'output_audio_path': row[0], 'output_video_path': row[1]}


def fetch_job_status(job_id: int) -> Optional[Dict]:
    with get_db_cursor() as cur:
        cur.execute('SELECT status, percent, error_text FROM jobs WHERE id=?', (job_id,))
        row = cur.fetchone()
        if not row:
            return None
        return {'status': row[0], 'progress': row[1], 'error_message': row[2]}


def fetch_processed_videos() -> List[Dict]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        cur.execute(
            '''SELECT id, source_url, output_audio_path, output_video_path, finished_at
               FROM jobs WHERE status IN ("done", "completed") AND source_url IS NOT NULL
               ORDER BY finished_at DESC'''
        )
        rows = cur.fetchall()
        return [
            {
                'id': row['id'],
                'source_url': row['source_url'],
                'output_audio_path': row['output_audio_path'],
                'output_video_path': row['output_video_path'],
                'finished_at': row['finished_at'],
            }
            for row in rows
        ]
    finally:
        conn.close()


def find_processed_audio(url: str, quality: Optional[str] = None) -> Optional[Dict]:
    with get_db_cursor() as cur:
        if quality:
            cur.execute(
                'SELECT id, output_audio_path FROM jobs WHERE source_url=? AND quality=? AND output_audio_path IS NOT NULL '
                'AND status IN ("done", "completed") ORDER BY id DESC LIMIT 1',
                (url, quality),
            )
        else:
            # Fallback for legacy jobs or when quality doesn't matter (e.g. audio only)
            # We prioritize jobs that match the URL.
            cur.execute(
                'SELECT id, output_audio_path FROM jobs WHERE source_url=? AND output_audio_path IS NOT NULL '
                'AND status IN ("done", "completed") ORDER BY id DESC LIMIT 1',
                (url,),
            )
        row = cur.fetchone()
        if not row:
            return None
        return {'job_id': row[0], 'output_audio_path': row[1]}


def delete_job(job_id: int, delete_files: bool = False) -> bool:
    with get_db_cursor(commit=True) as cur:
        cur.execute('SELECT output_audio_path, output_video_path FROM jobs WHERE id=?', (job_id,))
        row = cur.fetchone()
        cur.execute('DELETE FROM job_steps WHERE job_id=?', (job_id,))
        cur.execute('DELETE FROM jobs WHERE id=?', (job_id,))
    
    if delete_files and row:
        allowed_dirs = [os.path.abspath(path) for path in get_allowed_download_dirs()]
        for file_path in row:
            if not file_path or not os.path.exists(file_path):
                continue
            abs_path = os.path.abspath(file_path)
            if any(abs_path.startswith(allowed) for allowed in allowed_dirs):
                try:
                    os.remove(abs_path)
                except Exception:
                    pass
    return True


def get_job_audio_path(job_id: int) -> Optional[str]:
    with get_db_cursor() as cur:
        cur.execute('SELECT output_audio_path FROM jobs WHERE id=?', (job_id,))
        row = cur.fetchone()
        return row[0] if row else None


def is_job_cancelled(job_id: int) -> bool:
    try:
        with get_db_cursor() as cur:
            cur.execute('SELECT status FROM jobs WHERE id=?', (job_id,))
            row = cur.fetchone()
            return bool(row and row[0] == 'cancelled')
    except Exception:
        return False


def mark_incomplete_jobs_as_failed() -> None:
    with get_db_cursor(commit=True) as cur:
        now = datetime.utcnow().isoformat()
        cur.execute(
            '''UPDATE jobs 
               SET status='error', 
                   error_text='توقف الخادم بشكل غير متوقع', 
                   message='فشل بسبب إعادة تشغيل الخادم',
                   finished_at=? 
               WHERE status NOT IN ('done', 'error', 'cancelled', 'completed')''',
            (now,)
        )


def get_job(job_id: int) -> Optional[Dict]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        cur = conn.cursor()
        cur.execute(
            '''SELECT id, source_type, source_url, input_path, status, message,
                      phase, percent, created_at, updated_at, output_audio_path,
                      output_video_path, finished_at, error_text
               FROM jobs WHERE id=?''',
            (job_id,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return {
            'id': row['id'],
            'source_type': row['source_type'],
            'source_url': row['source_url'],
            'input_path': row['input_path'],
            'status': row['status'],
            'message': row['message'],
            'phase': row['phase'],
            'percent': row['percent'],
            'created_at': row['created_at'],
            'updated_at': row['updated_at'],
            'output_audio_path': row['output_audio_path'],
            'output_video_path': row['output_video_path'],
            'finished_at': row['finished_at'],
            'error_text': row['error_text'],
            'title': _infer_title(row),
        }
    finally:
        conn.close()
