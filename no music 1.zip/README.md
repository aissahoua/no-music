# Music Remover - No Music

Open-source project to remove music from video and audio content while preserving original audio quality. Developed as a free service to help users enjoy video content without music.

## 🌟 Key Features

### Web Interface
- Remove music from local audio/video files
- Support for YouTube audio/video links
- Clear execution states with progress bar
- Download clean audio or final video

### Browser Extension (Chrome)
- "Remove Music" button on YouTube video cards
- Smart queue for automatic video processing
- Auto-play clean audio when opening processed videos
- Smart cache for processed links (~50 bytes per link)
- Buttons on all suggested videos (home, search, playlists, etc.)

## 🚀 Quick Start

### Requirements
- Python 3.11+
- Windows 10/11
- Chrome browser (for browser extension)

### Installation

1. **Download Project**
   ```bash
   git clone https://github.com/yourusername/no-music.git
   cd no-music
   ```

2. **Create Virtual Environment & Install Requirements**
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Run Server**
   ```bash
   python server.py
   ```
   Or use `start.bat`

4. **Install Browser Extension (Optional)**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked"
   - Select `no music extention` folder

## 📖 Usage

### Via Web Interface
1. Open browser at `http://localhost:5000`
2. Select local file or enter YouTube link
3. Click "Start Execution"
4. Wait for processing to complete
5. Download clean audio or final video

### Via Browser Extension
1. Open any YouTube video
2. Find "Remove Music" button in control bar
3. Click to process video
4. Clean audio will play automatically
5. Buttons on thumbnail images for pre-processing videos

## ⚙️ Configuration

### Switch Between CPU/GPU
- In web interface: Use menu in top bar to switch mode
- In `mode.txt`: Change value to `CPU` or `GPU`

### Change Output Folder
- Edit `config.json` to change default path

## 📁 Project Structure

```
Music-Remover/
├── server.py              # Main server
├── web_interface.html     # Web interface
├── requirements.txt       # Requirements
├── config.json           # Settings file
├── mode.txt              # Processing mode (CPU/GPU)
├── start.bat             # Quick start file
├── no music extention/   # Browser extension
├── .venv/                # Virtual environment
└── README_AR.md          # Arabic README
```

## 🛠️ Development

### Implement New Features
1. Branch from `main`
2. Implement new features
3. Test locally
4. Open Pull Request

### Improve Browser Extension
- Review `no music extention/modules/` to understand structure
- Use `test-cache.html` to test caching

## 🤝 Contribution

Contributions welcome! If you have suggestions or improvements:

1. Open Issue to discuss idea
2. Create new branch
3. Implement changes
4. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file for details.

## ❤️ Dedication

This project is dedicated to my parents, developed with the intention of removing music from digital content for users seeking a music-free environment.

## 📞 Support

For any questions or issues, please open an Issue in the repository.

---

*Developed as a free and open-source service.*