// إضافة no-music
console.log("إضافة (no-music) قيد التشغيل");

(function () {
    'use strict';

    // Initialize local cache manager
    const cacheManager = new window.LocalCacheManager();
    
    // Initialize cache on load
    cacheManager.initializeCache().then(() => {
        console.log("no-music: Local cache initialized");
    }).catch(e => {
        console.error("no-music: Error initializing cache:", e);
    });

    // Thumbnail button manager feature removed as it was not working

    // Use MutationObserver instead of setInterval for better performance
    const observer = new MutationObserver(window.noMusicUtils.debounce(() => {
        // Try to inject the button
        if (window.ButtonManager.injectButton()) {
            // If successful, disconnect the observer
            observer.disconnect();
        }
    }, 300));

    // Start observing
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Watch for YouTube SPA navigation to clean up when switching videos
    if (!window.__noMusicNavWatcher) {
        window.__noMusicNavWatcher = (function () {
            let last = location.href;
            return setInterval(() => {
                if (location.href !== last) {
                    last = location.href;
                    window.AudioManager.deactivateNoMusic();
                }
            }, 750);
        })();
    }

    // Listen for YouTube internal navigation events if available
    try {
        window.addEventListener('yt-navigate-start', window.AudioManager.deactivateNoMusic);
        window.addEventListener('yt-navigate-finish', window.AudioManager.deactivateNoMusic);
    } catch (e) { }

    console.log("no-music: Extension initialized with modular structure and local caching.");
})();