// فتح واجهة الويب عند نقر أيقونة الإضافة في شريط أدوات المتصفح
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'http://localhost:5000/' });
});