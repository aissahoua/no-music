document.addEventListener('DOMContentLoaded', () => {
    const API_BASE = 'http://localhost:5000';
    const serverStatusDot = document.querySelector('#serverStatus .dot');
    const serverStatusText = document.querySelector('#serverStatus .status-text');
    const jobsList = document.getElementById('jobsList');
    const viewAllBtn = document.getElementById('viewAllBtn');

    // 1. Load Cached Jobs
    chrome.storage.local.get(['cachedJobs'], (result) => {
        if (result.cachedJobs) {
            renderJobs(result.cachedJobs);
        }
    });

    // 2. Check Server Status & Update Jobs
    async function checkServer() {
        try {
            const res = await fetch(`${API_BASE}/health`);
            if (res.ok) {
                serverStatusDot.className = 'dot online';
                serverStatusText.textContent = 'متصل';
                loadJobs();
            } else {
                throw new Error('Server error');
            }
        } catch (e) {
            serverStatusDot.className = 'dot offline';
            serverStatusText.textContent = 'غير متصل';
            // Keep showing cached jobs if available, otherwise show error
            chrome.storage.local.get(['cachedJobs'], (result) => {
                if (!result.cachedJobs || result.cachedJobs.length === 0) {
                    jobsList.innerHTML = `
                        <div class="empty-state">
                            <p>تعذر الاتصال بالسيرفر المحلي</p>
                            <button id="retryBtn" style="margin-top:10px; padding:4px 12px; border-radius:4px; border:1px solid #333; background:#222; color:#fff; cursor:pointer">إعادة المحاولة</button>
                        </div>
                    `;
                    document.getElementById('retryBtn')?.addEventListener('click', checkServer);
                }
            });
        }
    }

    // 3. Load Jobs from Server
    async function loadJobs() {
        try {
            const res = await fetch(`${API_BASE}/jobs`);
            if (!res.ok) throw new Error('Failed to fetch jobs');
            const allJobs = await res.json();

            // Filter only extension jobs
            const extensionJobs = allJobs.filter(job => job.source_type === 'extension');
            const recentJobs = extensionJobs.slice(0, 5);

            // Cache and Render
            chrome.storage.local.set({ cachedJobs: recentJobs });
            renderJobs(recentJobs);
        } catch (e) {
            console.error(e);
            // If fetch fails, we rely on cache loaded at start
        }
    }

    function renderJobs(jobs) {
        if (!jobs || jobs.length === 0) {
            jobsList.innerHTML = '<div class="empty-state">لا توجد مهام حديثة</div>';
            return;
        }

        jobsList.innerHTML = jobs.map(job => {
            const statusClass = getStatusClass(job.status);
            const statusText = getStatusText(job.status);
            const thumbUrl = getYouTubeThumbnail(job.source_url);

            return `
                <div class="job-item" data-url="${job.source_url || ''}">
                    <div class="job-thumb">
                        <img src="${thumbUrl}" alt="Thumb" onerror="this.src='icon.png'">
                    </div>
                    <div class="job-info">
                        <div class="job-title" title="${job.title || 'بدون عنوان'}">${job.title || 'جاري المعالجة...'}</div>
                        <div class="job-meta">
                            <span class="status-badge ${statusClass}">${statusText}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Add click listeners to open YouTube video
        document.querySelectorAll('.job-item').forEach(item => {
            item.addEventListener('click', () => {
                const url = item.dataset.url;
                if (url) {
                    chrome.tabs.create({ url: url });
                }
            });
        });
    }

    // Helpers
    function getYouTubeThumbnail(url) {
        if (!url) return 'icon.png';
        try {
            let videoId = null;
            if (url.includes('v=')) {
                videoId = url.split('v=')[1].split('&')[0];
            } else if (url.includes('youtu.be/')) {
                videoId = url.split('youtu.be/')[1].split('?')[0];
            }

            if (videoId) {
                return `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;
            }
        } catch (e) {
            console.error('Error parsing video ID', e);
        }
        return 'icon.png';
    }

    function getStatusClass(status) {
        if (['done', 'completed'].includes(status)) return 'done';
        if (['error', 'cancelled'].includes(status)) return 'error';
        return 'processing';
    }

    function getStatusText(status) {
        const map = {
            'queued': 'في الانتظار',
            'started': 'بدأ',
            'downloading': 'تحميل...',
            'downloaded': 'تم التحميل',
            'separating': 'فصل...',
            'merging': 'دمج...',
            'done': 'جاهز',
            'error': 'خطأ',
            'cancelled': 'ملغى'
        };
        return map[status] || status;
    }

    // 4. View All Button
    viewAllBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: API_BASE });
    });

    // Initial run
    checkServer();
});
