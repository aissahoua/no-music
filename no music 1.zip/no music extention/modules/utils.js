// Utility functions for the no-music extension

/**
 * Sanitize a filename by removing invalid characters
 * @param {string} name - The filename to sanitize
 * @returns {string} - The sanitized filename
 */
function sanitizeFilename(name) {
    // Remove invalid characters for Windows and reduce multiple spaces
    name = name.replace(/[\\/:*?"<>|]/g, '');
    name = name.replace(/\s+/g, ' ').trim();
    // Reasonable length limit
    return name.length > 120 ? name.substring(0, 120) : name;
}

/**
 * Get a parameter value from URL
 * @param {string} url - The URL to parse
 * @param {string} param - The parameter name
 * @returns {string|null} - The parameter value or null
 */
function getUrlParameter(url, param) {
    try {
        const urlObj = new URL(url);
        return urlObj.searchParams.get(param);
    } catch (e) {
        return null;
    }
}

/**
 * Debounce function to limit the rate at which a function is called
 * @param {Function} func - The function to debounce
 * @param {number} delay - The delay in milliseconds
 * @returns {Function} - The debounced function
 */
function debounce(func, delay) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}

/**
 * Safe resume for AudioContext
 * @param {AudioContext} ctx - The AudioContext to resume
 * @returns {Promise} - A promise that resolves when the context is resumed
 */
function safeResumeContext(ctx) {
    try {
        if (ctx && ctx.state === 'suspended') {
            return ctx.resume().catch(() => { });
        }
    } catch (e) { }
    return Promise.resolve();
}

// Export functions
window.noMusicUtils = {
    sanitizeFilename,
    getUrlParameter,
    debounce,
    safeResumeContext
};