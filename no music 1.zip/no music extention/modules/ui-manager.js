// UI Management for the no-music extension

/**
 * Create and manage the loading overlay
 */
class LoadingOverlayManager {
    /**
     * Create a loading overlay over the video player
     */
    static createLoadingOverlay() {
        // Remove any existing overlay
        this.removeLoadingOverlay();

        // Get the video player element
        const videoPlayer = document.querySelector('.html5-video-player');
        if (!videoPlayer) {
            console.error('no-music: Video player not found');
            return;
        }

        // Create the overlay element
        const overlay = document.createElement('div');
        overlay.id = 'no-music-loading-overlay';
        overlay.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.85);
            z-index: 1000;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            font-family: 'Cairo', sans-serif;
            pointer-events: none;
        `;

        // Create spinner
        const spinner = document.createElement('div');
        spinner.style.cssText = `
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid #26c6da;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        `;

        // Create title
        const title = document.createElement('h2');
        title.textContent = 'جاري إزالة الموسيقى';
        title.style.cssText = `
            margin: 0 0 15px 0;
            color: #26c6da;
            font-size: 24px;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
        `;

        // Create progress container
        const progressContainer = document.createElement('div');
        progressContainer.style.cssText = `
            width: 80%;
            max-width: 400px;
            height: 6px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 3px;
            margin: 20px 0;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.5);
        `;

        // Create progress bar
        const progressBar = document.createElement('div');
        progressBar.id = 'no-music-progress-bar';
        progressBar.style.cssText = `
            height: 100%;
            background: linear-gradient(90deg, #26c6da, #00e676);
            width: 0%;
            transition: width 0.3s ease;
            border-radius: 3px;
        `;

        // Create status text
        const statusText = document.createElement('p');
        statusText.id = 'no-music-status-text';
        statusText.textContent = 'جاري تحميل الفيديو...';
        statusText.style.cssText = `
            margin: 15px 0 0 0;
            color: #ccc;
            font-size: 16px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.8);
        `;

        // Create percentage text
        const percentageText = document.createElement('p');
        percentageText.id = 'no-music-percentage';
        percentageText.textContent = '0%';
        percentageText.style.cssText = `
            margin: 10px 0 0 0;
            color: #26c6da;
            font-size: 18px;
            font-weight: bold;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.8);
        `;

        // Assemble elements
        progressContainer.appendChild(progressBar);
        overlay.appendChild(spinner);
        overlay.appendChild(title);
        overlay.appendChild(progressContainer);
        overlay.appendChild(statusText);
        overlay.appendChild(percentageText);

        // Add CSS for spinner animation
        if (!document.getElementById('no-music-spinner-style')) {
            const style = document.createElement('style');
            style.id = 'no-music-spinner-style';
            style.textContent = `
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }

        // Position the video player relatively and add the overlay
        videoPlayer.style.position = 'relative';
        videoPlayer.appendChild(overlay);

        console.log('no-music: Loading overlay created');
    }

    /**
     * Update the loading progress
     * @param {number} percentage - Progress percentage (0-100)
     * @param {string} status - Status message
     */
    static updateLoadingProgress(percentage, status) {
        const progressBar = document.getElementById('no-music-progress-bar');
        const statusText = document.getElementById('no-music-status-text');
        const percentageText = document.getElementById('no-music-percentage');

        if (progressBar) {
            progressBar.style.width = percentage + '%';
        }

        if (statusText) {
            statusText.textContent = status;
        }

        if (percentageText) {
            percentageText.textContent = percentage + '%';
        }

        console.log(`no-music: Progress updated - ${percentage}%: ${status}`);
    }

    /**
     * Remove the loading overlay
     */
    static removeLoadingOverlay() {
        const overlay = document.getElementById('no-music-loading-overlay');
        if (overlay) {
            overlay.remove();
            console.log('no-music: Loading overlay removed');
        }
    }
}

/**
 * Manage the no-music button UI state
 */
class ButtonUIManager {
    /**
     * Set the active state of the no-music button
     * @param {boolean} active - Whether the clean audio is active
     */
    static setNoMusicActive(active) {
        try {
            const btn = document.getElementById('no-music-player-button');
            if (!btn) return;

            if (active) {
                // Show "currently without music" icon when clean audio is playing
                btn.innerHTML = '<svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_1_2)"><circle cx="17" cy="17" r="17" fill="#D9D9D9"/><path fill-rule="evenodd" clip-rule="evenodd" d="M26 10.8513V19.4021C26 21.5191 24.3556 23.3538 22.296 23.304C19.9374 23.2459 18.1186 20.8466 19.0072 18.2814C19.4972 16.8701 20.8675 15.9486 22.3292 15.9237C23.0268 15.9154 23.276 16.0897 24.1978 16.4135V13.6158C24.1978 13.1094 23.7992 12.6943 23.3009 12.6943H16.1171C15.6188 12.6943 15.2118 13.1094 15.2118 13.6158V23.0881C15.2118 25.2134 13.5591 27.0647 11.4912 26.9983C9.50632 26.9319 7.92007 25.2217 8.00312 23.1545C8.07786 21.1621 9.78869 19.6595 11.7321 19.6097C12.6456 19.5848 12.8117 19.7342 13.418 20.1078V10.8513C13.418 9.83018 14.2235 9 15.2118 9H24.1978C25.1944 9 26 9.83018 26 10.8513Z" fill="#313131"/><path fill-rule="evenodd" clip-rule="evenodd" d="M17 34C7.6 34 0 26.4 0 17C0 7.6 7.6 0 17 0C26.4 0 34 7.6 34 17C34 26.4 26.4 34 17 34ZM17 32.11C20.83 32.11 24.32 30.67 26.98 28.32L5.68 7.02C3.33 9.68 1.89 13.17 1.89 17C1.89 25.33 8.67 32.11 17 32.11ZM32.11 17C32.11 8.67 25.33 1.89 17 1.89C13.17 1.89 9.68 3.33 7.02 5.68L28.32 26.98C30.67 24.32 32.11 20.83 32.11 17Z" fill="#313131"/></g><defs><clipPath id="clip0_1_2"><rect width="34" height="34" fill="white"/></clipPath></defs></svg>';
                btn.setAttribute('aria-pressed', 'true');
                btn.title = 'الصوت الصافي مفعل';
            } else {
                // Show default icon immediately
                btn.innerHTML = '<svg version="1.2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 34 34" width="100%" height="100%"><style>.s0 { fill: #f6f6f6 }</style><path id="music-[#1005]" fill-rule="evenodd" class="s0" d="m27.84 8.39v10.3c0 2.55-1.98 4.76-4.46 4.7-2.84-0.07-5.03-2.96-3.96-6.05 0.59-1.7 2.24-2.81 4-2.84 0.84-0.01 1.14 0.2 2.25 0.59v-3.37c0-0.61-0.48-1.11-1.08-1.11h-8.65c-0.6 0-1.09 0.5-1.09 1.11v11.41c0 2.56-1.99 4.79-4.48 4.71-2.39-0.08-4.3-2.14-4.2-4.63 0.09-2.4 2.15-4.21 4.49-4.27 1.1-0.03 1.3 0.15 2.03 0.6v-11.15c0-1.23 0.97-2.23 2.16-2.23h10.82c1.2 0 2.17 1 2.17 2.23z"/><path fill-rule="evenodd" class="s0" d="m17 34c-9.4 0-17-7.6-17-17 0-9.4 7.6-17 17-17 9.4 0 17 7.6 17 17 0 9.4-7.6 17-17 17zm0-1.89c3.83 0 7.32-1.44 9.98-3.79l-21.3-21.3c-2.35 2.66-3.79 6.15-3.79 9.98 0 8.33 6.78 15.11 15.11 15.11zm15.11-15.11c0-8.33-6.78-15.11-15.11-15.11-3.83 0-7.32 1.44-9.98 3.79l21.3 21.3c2.35-2.66 3.79-6.15 3.79-9.98z"/></svg>';

                // Check if audio has been processed before (in background)
                const currentUrl = window.location.href;
                fetch('http://localhost:5000/check_processed', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ url: currentUrl })
                })
                    .then(res => res.json())
                    .then(cp => {
                        // Only update if button still exists and we're not in active state
                        if (document.getElementById('no-music-player-button') && (!btn.hasAttribute('aria-pressed') || btn.getAttribute('aria-pressed') !== 'true')) {
                            if (cp && cp.found && cp.audio_url) {
                                // Show "already processed" icon when audio was previously processed
                                btn.innerHTML = '<svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_1_2)"><circle cx="22" cy="22" r="22" fill="#D9D9D9"/><path fill-rule="evenodd" clip-rule="evenodd" d="M6.44365 6.44365C15.0454 -2.1581 28.9546 -2.1581 37.5564 6.44365C46.1581 15.0454 46.1581 28.9546 37.5564 37.5563C28.9546 46.1581 15.0454 46.1581 6.44365 37.5563C-2.15809 28.9546 -2.15809 15.0454 6.44365 6.44365ZM8.17315 8.17315C4.6684 11.6779 2.79249 16.1892 2.50881 20.7738H41.4912C41.2075 16.1892 39.3316 11.6779 35.8269 8.17315C28.2042 0.550539 15.7958 0.550539 8.17315 8.17315ZM8.17315 35.8268C15.7958 43.4495 28.2042 43.4495 35.8269 35.8268C39.3316 32.3221 41.2075 27.8108 41.4912 23.2262H2.50881C2.79249 27.8108 4.6684 32.3221 8.17315 35.8268Z" fill="#313131"/><circle cx="22.0588" cy="22.0588" r="20.0588" fill="#D9D9D9"/><path d="M36.5 20.634C37.1667 21.0189 37.1667 21.9811 36.5 22.366L14.75 34.9234C14.0833 35.3083 13.25 34.8272 13.25 34.0574L13.25 8.94263C13.25 8.17283 14.0833 7.6917 14.75 8.07661L36.5 20.634Z" fill="#313131"/></g><defs><clipPath id="clip0_1_2"><rect width="44" height="44" fill="white"/></clipPath></defs></svg>';
                            }
                        }
                    })
                    .catch(error => {
                        // Keep default icon on error
                        console.log('no-music: Error checking processed state:', error);
                    });

                btn.setAttribute('aria-pressed', 'false');
                btn.title = 'إزالة الموسيقى (إضافة)';
            }
        } catch (e) { }
    }

    /**
     * Set the availability state of no-music for the current video
     * @param {boolean} available - Whether no-music is available
     */
    static setNoMusicAvailable(available) {
        // This function can be used to indicate availability of processed audio
        // For now, we'll just refresh the icon state
        this.setNoMusicActive(false);
    }
}

/**
 * Manage toast notifications
 */
class ToastManager {
    static showToast(message, duration = 5000) {
        // Remove existing toast
        const existing = document.getElementById('no-music-toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.id = 'no-music-toast';
        toast.textContent = message;
        toast.style.cssText = `
            position: fixed;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(38, 198, 218, 0.95);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            font-family: 'Cairo', sans-serif;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s ease;
            pointer-events: none;
        `;

        document.body.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.style.opacity = '1';
        });

        // Auto hide
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
}

// Export classes
window.LoadingOverlayManager = LoadingOverlayManager;
window.ButtonUIManager = ButtonUIManager;
window.ToastManager = ToastManager;