// Audio Management for the no-music extension

/**
 * Manage audio replacement and synchronization
 */
class AudioManager {
    /**
     * Replace video audio with clean audio
     * @param {HTMLVideoElement} video - The video element
     * @param {string} audioUrl - The URL of the clean audio
     * @param {number} currentTime - The current time to start playback
     */
    static replaceVideoAudio(video, audioUrl, currentTime) {
        if (!video || !audioUrl) {
            console.error('no-music: Video or audio URL missing');
            window.LoadingOverlayManager.removeLoadingOverlay();
            if (video) {
                video.currentTime = currentTime;
                video.play();
            }
            return;
        }

        console.log('no-music: Replacing audio with clean version...');

        // More reliable approach: use Web Audio API to merge audio
        try {
            // Save current settings
            const wasPlaying = !video.paused;
            const playbackRate = video.playbackRate;
            const videoSrc = video.currentSrc || video.src;

            // Pause current video and mute it
            video.pause();
            // We'll make the video permanently muted, and bind volume/state to the new audio file
            this.enforceVideoMuted(video);

            // Create new audio element for clean audio
            const audioElement = new Audio(audioUrl);
            audioElement.crossOrigin = 'anonymous';
            audioElement.playbackRate = playbackRate;
            audioElement.preload = 'auto';

            // Create Web Audio Context
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();

            // Create source for clean audio
            const audioSource = audioContext.createMediaElementSource(audioElement);
            const gainNode = audioContext.createGain();
            audioSource.connect(gainNode);
            gainNode.connect(audioContext.destination);

            // Synchronize audio with video in an advanced way
            this.attachSyncHandlers(video, audioElement, audioContext);
            // Store references on video element for easy cleanup during navigation
            video.__noMusicAudio = audioElement;
            video.__noMusicAudioCtx = audioContext;
            video.__noMusicSrc = video.currentSrc || video.src;
            // Also store on window level to ensure access even after video element changes within SPA
            window.__noMusicAudio = audioElement;
            window.__noMusicAudioCtx = audioContext;
            window.__noMusicOldVideo = video;

            // Remove loading overlay
            window.LoadingOverlayManager.removeLoadingOverlay();

            // Play video with new audio
            video.currentTime = currentTime;
            if (wasPlaying) {
                video.play().then(() => {
                    window.noMusicUtils.safeResumeContext(audioContext).then(() => {
                        audioElement.currentTime = video.currentTime;
                        audioElement.play();
                        // Show active state because clean audio is now playing
                        window.ButtonUIManager.setNoMusicActive(true);
                        console.log('no-music: Video playing with clean audio!');
                    });
                }).catch(error => {
                    console.error('no-music: Error playing video:', error);
                    // In case of error, revert to original video
                    video.play();
                    window.ButtonUIManager.setNoMusicActive(false);
                });
            } else {
                // Even if not playing, we still want to show the active state
                window.ButtonUIManager.setNoMusicActive(true);
            }

            // Show simple notification for autoplay if this function was called from auto-check
            if (window._noMusicAutoPlayCheck) {
                setTimeout(this.showAutoPlayNotification, 500);
                window._noMusicAutoPlayCheck = false;
            }

            console.log('no-music: Audio replaced successfully!');

        } catch (error) {
            console.error('no-music: Error replacing audio:', error);
            // In case of error, revert to original video
            video.currentTime = currentTime;
            video.play();
            window.LoadingOverlayManager.removeLoadingOverlay();
        }
    }

    /**
     * Show autoplay notification
     */
    static showAutoPlayNotification() {
        // Remove any existing notifications
        const existingNotification = document.getElementById('no-music-auto-notification');
        if (existingNotification) {
            existingNotification.remove();
        }

        // Create notification element
        const notification = document.createElement('div');
        notification.id = 'no-music-auto-notification';
        notification.innerHTML = '<svg width="24" height="24" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle; margin-left: 8px;"><g clip-path="url(#clip0_1_2)"><circle cx="17" cy="17" r="17" fill="#D9D9D9"/><path fill-rule="evenodd" clip-rule="evenodd" d="M26 10.8513V19.4021C26 21.5191 24.3556 23.3538 22.296 23.304C19.9374 23.2459 18.1186 20.8466 19.0072 18.2814C19.4972 16.8701 20.8675 15.9486 22.3292 15.9237C23.0268 15.9154 23.276 16.0897 24.1978 16.4135V13.6158C24.1978 13.1094 23.7992 12.6943 23.3009 12.6943H16.1171C15.6188 12.6943 15.2118 13.1094 15.2118 13.6158V23.0881C15.2118 25.2134 13.5591 27.0647 11.4912 26.9983C9.50632 26.9319 7.92007 25.2217 8.00312 23.1545C8.07786 21.1621 9.78869 19.6595 11.7321 19.6097C12.6456 19.5848 12.8117 19.7342 13.418 20.1078V10.8513C13.418 9.83018 14.2235 9 15.2118 9H24.1978C25.1944 9 26 9.83018 26 10.8513Z" fill="#313131"/><path fill-rule="evenodd" clip-rule="evenodd" d="M17 34C7.6 34 0 26.4 0 17C0 7.6 7.6 0 17 0C26.4 0 34 7.6 34 17C34 26.4 26.4 34 17 34ZM17 32.11C20.83 32.11 24.32 30.67 26.98 28.32L5.68 7.02C3.33 9.68 1.89 13.17 1.89 17C1.89 25.33 8.67 32.11 17 32.11ZM32.11 17C32.11 8.67 25.33 1.89 17 1.89C13.17 1.89 9.68 3.33 7.02 5.68L28.32 26.98C30.67 24.32 32.11 20.83 32.11 17Z" fill="#313131"/></g><defs><clipPath id="clip0_1_2"><rect width="34" height="34" fill="white"/></clipPath></defs></svg> تم تشغيل الصوت الصافي تلقائيًا';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(28, 28, 28, 0.9);
            color: #eee;
            padding: 12px 16px;
            border-radius: 4px;
            font-family: 'Roboto', 'Arial', sans-serif;
            font-size: 14px;
            font-weight: 500;
            z-index: 9999;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            transition: opacity 0.3s ease;
            opacity: 0;
            transform: translateY(-10px);
            direction: rtl;
            display: flex;
            align-items: center;
        `;

        // Add notification to page
        document.body.appendChild(notification);

        // Show notification with effect
        setTimeout(() => {
            notification.style.opacity = '1';
            notification.style.transform = 'translateY(0)';
        }, 100);

        // Remove notification automatically after 3 seconds
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    /**
     * Ensure video stays muted permanently
     * @param {HTMLVideoElement} video - The video element
     */
    static enforceVideoMuted(video) {
        try {
            // Don't change video.volume value so the volume bar still works
            video.muted = true;
            // Watch volume/mute changes to apply them to the new audio instead of the video
            if (!video.__noMusicMuteHandler) {
                video.__noMusicMuteHandler = (e) => {
                    // Don't allow video audio to return
                    if (!video.muted) {
                        // Extract user mute state from YouTube interface via video property before re-muting
                        const userMuted = video.muted;
                        // Re-mute video immediately
                        setTimeout(() => { video.muted = true; }, 0);
                    }
                };
                video.addEventListener('volumechange', video.__noMusicMuteHandler);
            }
            // Periodically re-enforce to prevent any unmuting from YouTube
            if (!window.__noMusicEnforceInterval) {
                window.__noMusicEnforceInterval = setInterval(() => {
                    if (!video.muted) video.muted = true;
                }, 500);
            }
        } catch (e) {
            console.warn('no-music: enforceVideoMuted failed', e);
        }
    }

    /**
     * Attach full synchronization between video and new audio
     * @param {HTMLVideoElement} video - The video element
     * @param {HTMLAudioElement} audioElement - The audio element
     * @param {AudioContext} audioContext - The audio context
     */
    static attachSyncHandlers(video, audioElement, audioContext) {
        try {
            // Make volume and mute dependent on video (YouTube interface)
            const applyVolumeFromVideo = () => {
                try {
                    // Use video.volume value for new audio element
                    audioElement.volume = video.volume;
                    // Use mute state via video.muted property before re-muting video
                    audioElement.muted = false; // We control mute via new audio only
                } catch (e) { }
            };

            // Synchronize time with drift handling
            const resyncIfDrift = () => {
                try {
                    const drift = Math.abs((audioElement.currentTime || 0) - (video.currentTime || 0));
                    if (drift > 0.25) {
                        audioElement.currentTime = video.currentTime;
                    }
                } catch (e) { }
            };

            // General control events
            const onPlay = () => {
                window.noMusicUtils.safeResumeContext(audioContext).then(() => {
                    audioElement.currentTime = video.currentTime;
                    audioElement.play().catch(() => { });
                });
            };
            const onPause = () => { audioElement.pause(); };
            const onSeeked = () => { audioElement.currentTime = video.currentTime; };
            const onSeeking = () => { audioElement.currentTime = video.currentTime; };
            const onRateChange = () => { audioElement.playbackRate = video.playbackRate; };
            const onTimeUpdate = () => { resyncIfDrift(); };
            const onVolumeChange = () => { applyVolumeFromVideo(); };

            // Bind handlers once
            if (!video.__noMusicHandlersAttached) {
                video.addEventListener('play', onPlay);
                video.addEventListener('pause', onPause);
                video.addEventListener('seeked', onSeeked);
                video.addEventListener('seeking', onSeeking);
                video.addEventListener('ratechange', onRateChange);
                video.addEventListener('timeupdate', onTimeUpdate);
                video.addEventListener('volumechange', onVolumeChange);
                video.__noMusicHandlersAttached = true;
                // Store these handlers to remove them later when video changes
                video.__noMusicHandlers = { onPlay, onPause, onSeeked, onSeeking, onRateChange, onTimeUpdate, onVolumeChange };
            }

            // Apply initial settings
            audioElement.playbackRate = video.playbackRate;
            audioElement.currentTime = video.currentTime;
            applyVolumeFromVideo();

            // If context is suspended, resume it on first interaction
            document.addEventListener('click', () => window.noMusicUtils.safeResumeContext(audioContext), { once: true });
        } catch (e) {
            console.warn('no-music: attachSyncHandlers failed', e);
        }
    }

    /**
     * Remove handlers and synchronization from current video
     * @param {HTMLVideoElement} video - The video element
     */
    static removeSyncHandlers(video) {
        try {
            if (video && video.__noMusicHandlersAttached && video.__noMusicHandlers) {
                const h = video.__noMusicHandlers;
                video.removeEventListener('play', h.onPlay);
                video.removeEventListener('pause', h.onPause);
                video.removeEventListener('seeked', h.onSeeked);
                video.removeEventListener('seeking', h.onSeeking);
                video.removeEventListener('ratechange', h.onRateChange);
                video.removeEventListener('timeupdate', h.onTimeUpdate);
                video.removeEventListener('volumechange', h.onVolumeChange);
                video.__noMusicHandlersAttached = false;
                video.__noMusicHandlers = null;
            }
        } catch (e) { }
    }

    /**
     * Deactivate no-music and clean up when navigating to a new video
     */
    static deactivateNoMusic() {
        try {
            const currentVideo = document.querySelector('video');
            const oldVideo = window.__noMusicOldVideo || currentVideo;
            // Stop new audio if found (window reference)
            if (window.__noMusicAudio) {
                try {
                    window.__noMusicAudio.pause();
                    window.__noMusicAudio.src = '';
                    window.__noMusicAudio.load();
                    if (window.__noMusicAudio.remove) window.__noMusicAudio.remove();
                } catch (e) { }
                window.__noMusicAudio = null;
            }
            // Suspend/close audio context at window level
            if (window.__noMusicAudioCtx) {
                try { window.__noMusicAudioCtx.suspend(); } catch (e) { }
                try { window.__noMusicAudioCtx.close && window.__noMusicAudioCtx.close(); } catch (e) { }
                window.__noMusicAudioCtx = null;
            }
            // Remove sync handlers from old video if found
            this.removeSyncHandlers(oldVideo);
            // Remove permanent mute enforcer
            if (oldVideo && oldVideo.__noMusicMuteHandler) {
                try { oldVideo.removeEventListener('volumechange', oldVideo.__noMusicMuteHandler); } catch (e) { }
                oldVideo.__noMusicMuteHandler = null;
            }
            if (window.__noMusicEnforceInterval) {
                try { clearInterval(window.__noMusicEnforceInterval); } catch (e) { }
                window.__noMusicEnforceInterval = null;
            }
            // Restore original video audio to normal state
            try { if (currentVideo) currentVideo.muted = false; } catch (e) { }
            // Remove loading overlay if present
            window.LoadingOverlayManager.removeLoadingOverlay();
            // Remove active indicator from button
            window.ButtonUIManager.setNoMusicActive(false);
            console.log('no-music: Clean audio deactivated, ready for new video');
            // Clear old video reference
            window.__noMusicOldVideo = null;
        } catch (e) {
            console.warn('no-music: deactivateNoMusic failed', e);
        }
    }
}

// Export class
window.AudioManager = AudioManager;