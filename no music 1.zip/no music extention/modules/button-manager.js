// Button Management for the no-music extension

/**
 * Manage the no-music button injection and events
 */
class ButtonManager {
    /**
     * Create and inject the no-music button
     * @returns {HTMLElement|null} - The created button or null if failed
     */
    static createNoMusicButton() {
        const newButton = document.createElement('button');
        newButton.id = 'no-music-player-button';
        newButton.title = 'إزالة الموسيقى';
        newButton.className = 'ytp-button';
        newButton.style.cssText = 'display: flex; align-items: center; justify-content: center; position: relative;';

        // Set initial icon state immediately
        newButton.innerHTML = '<svg version="1.2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 34 34" width="100%" height="100%"><style>.s0 { fill: #f6f6f6 }</style><path id="music-[#1005]" fill-rule="evenodd" class="s0" d="m27.84 8.39v10.3c0 2.55-1.98 4.76-4.46 4.7-2.84-0.07-5.03-2.96-3.96-6.05 0.59-1.7 2.24-2.81 4-2.84 0.84-0.01 1.14 0.2 2.25 0.59v-3.37c0-0.61-0.48-1.11-1.08-1.11h-8.65c-0.6 0-1.09 0.5-1.09 1.11v11.41c0 2.56-1.99 4.79-4.48 4.71-2.39-0.08-4.3-2.14-4.2-4.63 0.09-2.4 2.15-4.21 4.49-4.27 1.1-0.03 1.3 0.15 2.03 0.6v-11.15c0-1.23 0.97-2.23 2.16-2.23h10.82c1.2 0 2.17 1 2.17 2.23z"/><path fill-rule="evenodd" class="s0" d="m17 34c-9.4 0-17-7.6-17-17 0-9.4 7.6-17 17-17 9.4 0 17 7.6 17 17 0 9.4-7.6 17-17 17zm0-1.89c3.83 0 7.32-1.44 9.98-3.79l-21.3-21.3c-2.35 2.66-3.79 6.15-3.79 9.98 0 8.33 6.78 15.11 15.11 15.11zm15.11-15.11c0-8.33-6.78-15.11-15.11-15.11-3.83 0-7.32 1.44-9.98 3.79l21.3 21.3c2.35-2.66 3.79-6.15 3.79-9.98z"/></svg>';

        return newButton;
    }

    /**
     * Add event listener to the no-music button
     * @param {HTMLElement} button - The button element
     */
    static addNoMusicButtonListener(button) {
        button.addEventListener('click', () => {
            console.log('no-music: Button clicked!');

            // Get current video URL
            const currentUrl = window.location.href;
            console.log('no-music: Video URL:', currentUrl);

            // Stop video immediately
            const video = document.querySelector('video');
            let currentTime = 0;
            if (video) {
                currentTime = video.currentTime;
                video.pause();
                console.log('no-music: Video paused at:', currentTime);
            }

            // Create loading overlay
            window.LoadingOverlayManager.createLoadingOverlay();
            // Set initial state to inactive until clean audio is playing
            window.ButtonUIManager.setNoMusicActive(false);

            // التحقق من التخزين المؤقت المحلي أولاً
            const cacheManager = new window.LocalCacheManager();

            if (cacheManager.isVideoProcessed(currentUrl)) {
                // الفيديو معالج، نحصل على رابط الصوت من السيرفر
                window.ServerCommunication.checkProcessed(currentUrl)
                    .then(cp => {
                        if (cp && cp.found && cp.audio_url) {
                            window.LoadingOverlayManager.updateLoadingProgress(100, 'هذا الفيديو تمت معالجته سابقًا، يتم التشغيل بالصوت الصافي الآن');
                            window.AudioManager.replaceVideoAudio(video, cp.audio_url, currentTime);
                        } else {
                            // الرابط في التخزين المؤقت لكن غير موجود في السيرفر، نعالجه من جديد
                            return window.ServerCommunication.processVideo(currentUrl);
                        }
                    })
                    .then(response => {
                        if (!response) return;
                        this.handleProcessingResponse(response, video, currentTime);
                    })
                    .catch(error => {
                        this.handleProcessingError(error, video, currentTime);
                    });
            } else {
                // الفيديو غير معالج، نتحقق من السيرفر ثم نعالجه
                window.ServerCommunication.checkProcessed(currentUrl)
                    .then(cp => {
                        if (cp && cp.found && cp.audio_url) {
                            window.LoadingOverlayManager.updateLoadingProgress(100, 'هذا الفيديو تمت معالجته سابقًا، يتم التشغيل بالصوت الصافي الآن');
                            window.AudioManager.replaceVideoAudio(video, cp.audio_url, currentTime);
                            // إضافة إلى التخزين المؤقت
                            cacheManager.addProcessedUrl(currentUrl);
                            return;
                        }
                        // إذا لم يكن معالج، نرسله للمعالجة
                        return window.ServerCommunication.processVideo(currentUrl);
                    })
                    .then(response => {
                        if (!response) return;
                        this.handleProcessingResponse(response, video, currentTime, currentUrl);
                    })
                    .catch(error => {
                        this.handleProcessingError(error, video, currentTime);
                    });
            }
        });
    }

    /**
     * Handle successful processing response
     */
    static handleProcessingResponse(response, video, currentTime, currentUrl) {
        console.log('no-music: URL sent successfully:', response);
        if (response.job_id) {
            // Start periodic progress updates while waiting for audio file
            window.ServerCommunication.startProgressUpdates(response.job_id, video, currentTime, response.audio_url);

            // إضافة الرابط إلى التخزين المؤقت بعد نجاح المعالجة
            if (currentUrl) {
                const cacheManager = new window.LocalCacheManager();
                cacheManager.addProcessedUrl(currentUrl);
            }
        } else {
            window.LoadingOverlayManager.updateLoadingProgress(100, 'تم إرسال الرابط بنجاح!');
            setTimeout(() => {
                window.LoadingOverlayManager.removeLoadingOverlay();
                if (video) {
                    video.play();
                    console.log('no-music: Video playing');
                }
            }, 2000);
        }
    }

    /**
     * Handle processing error
     */
    static handleProcessingError(error, video, currentTime) {
        console.error('no-music: Error sending/checking URL:', error);
        window.LoadingOverlayManager.updateLoadingProgress(0, 'حدث خطأ في إرسال الرابط');
        setTimeout(() => {
            window.LoadingOverlayManager.removeLoadingOverlay();
            if (video) {
                video.currentTime = currentTime;
                video.play();
                console.log('no-music: Video playing after error');
            }
        }, 3000);
    }

    /**
     * Inject button into YouTube player controls
     */
    static injectButton() {
        const settingsButton = document.querySelector('.ytp-settings-button');
        if (!settingsButton) return false;

        if (document.getElementById('no-music-player-button')) {
            return true; // Button already exists
        }

        const newButton = this.createNoMusicButton();
        if (!newButton) return false;

        // Set initial icon state
        window.ButtonUIManager.setNoMusicActive(false);

        // Add event listener
        this.addNoMusicButtonListener(newButton);

        // Insert button before settings button
        settingsButton.before(newButton);
        console.log("no-music: Button added successfully.");

        return true;
    }
}

// Export class
window.ButtonManager = ButtonManager;