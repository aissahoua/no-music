// Local Cache Management for the no-music extension
// تخزين بسيط لروابط المقاطع المعالجة فقط

/**
 * إدارة التخزين المؤقت لروابط المقاطع المعالجة
 */
class LocalCacheManager {
    constructor() {
        this.cacheKey = 'noMusicProcessedUrls';
    }

    /**
     * الحصول على قائمة روابط المقاطع المعالجة
     * @returns {Set} - مجموعة الروابط المعالجة
     */
    getProcessedUrls() {
        try {
            const cached = localStorage.getItem(this.cacheKey);
            return cached ? new Set(JSON.parse(cached)) : new Set();
        } catch (e) {
            console.error('no-music: Error reading cache:', e);
            return new Set();
        }
    }

    /**
     * حفظ قائمة الروابط المعالجة
     * @param {Set} urls - مجموعة الروابط
     */
    saveProcessedUrls(urls) {
        try {
            localStorage.setItem(this.cacheKey, JSON.stringify([...urls]));
        } catch (e) {
            console.error('no-music: Error saving cache:', e);
        }
    }

    /**
     * التحقق من وجود رابط في التخزين المؤقت
     * @param {string} url - رابط الفيديو
     * @returns {boolean} - true إذا كان المقطع معالج
     */
    isVideoProcessed(url) {
        const urls = this.getProcessedUrls();
        return urls.has(url);
    }

    /**
     * إضافة رابط إلى قائمة المقاطع المعالجة
     * @param {string} url - رابط الفيديو
     */
    addProcessedUrl(url) {
        const urls = this.getProcessedUrls();
        urls.add(url);
        this.saveProcessedUrls(urls);
    }

    /**
     * تحديث التخزين المؤقت من السيرفر
     * @returns {Promise<void>}
     */
    async refreshFromServer() {
        try {
            const response = await fetch('http://localhost:5000/processed_videos');
            const data = await response.json();
            
            if (data.videos && Array.isArray(data.videos)) {
                const urls = new Set(data.videos.map(v => v.source_url));
                this.saveProcessedUrls(urls);
                console.log(`no-music: Cache updated with ${urls.size} processed videos`);
            }
        } catch (error) {
            console.error('no-music: Error refreshing cache from server:', error);
        }
    }

    /**
     * تهيئة التخزين المؤقت
     */
    async initializeCache() {
        await this.refreshFromServer();
    }

    /**
     * مسح التخزين المؤقت
     */
    clearCache() {
        try {
            localStorage.removeItem(this.cacheKey);
            console.log('no-music: Cache cleared');
        } catch (e) {
            console.error('no-music: Error clearing cache:', e);
        }
    }
}

// Export class
window.LocalCacheManager = LocalCacheManager;
