// Cache Statistics Helper
// دوال مساعدة لعرض إحصائيات التخزين المؤقت

/**
 * عرض إحصائيات التخزين المؤقت في console
 */
function showCacheStats() {
    const cache = new LocalCacheManager();
    const urls = cache.getProcessedUrls();
    const dataStr = JSON.stringify([...urls]);
    const size = new Blob([dataStr]).size;
    
    console.group('📊 إحصائيات التخزين المؤقت - no-music');
    console.log(`📝 عدد الروابط المخزنة: ${urls.size}`);
    console.log(`💾 حجم التخزين: ${size} بايت (${(size / 1024).toFixed(2)} KB)`);
    console.log(`🔑 مفتاح التخزين: ${cache.cacheKey}`);
    console.log(`📈 متوسط حجم الرابط: ${urls.size > 0 ? (size / urls.size).toFixed(0) : 0} بايت`);
    
    if (urls.size > 0) {
        console.log(`\n📋 الروابط المخزنة:`);
        [...urls].forEach((url, i) => {
            console.log(`  ${i + 1}. ${url}`);
        });
    }
    
    console.groupEnd();
}

/**
 * مسح التخزين المؤقت مع تأكيد
 */
function clearCacheWithConfirm() {
    const cache = new LocalCacheManager();
    const urls = cache.getProcessedUrls();
    
    if (urls.size === 0) {
        console.log('ℹ️ التخزين المؤقت فارغ بالفعل');
        return;
    }
    
    console.warn(`⚠️ سيتم مسح ${urls.size} رابط من التخزين المؤقت`);
    console.log('لتأكيد المسح، اكتب: confirmClearCache()');
}

/**
 * تأكيد مسح التخزين المؤقت
 */
function confirmClearCache() {
    const cache = new LocalCacheManager();
    cache.clearCache();
    console.log('✅ تم مسح التخزين المؤقت بنجاح');
    showCacheStats();
}

/**
 * إضافة رابط تجريبي
 */
function addTestUrl(videoId = 'test123') {
    const cache = new LocalCacheManager();
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    cache.addProcessedUrl(url);
    console.log(`✅ تم إضافة رابط تجريبي: ${url}`);
    showCacheStats();
}

/**
 * التحقق من رابط
 */
function checkUrl(url) {
    const cache = new LocalCacheManager();
    const isProcessed = cache.isVideoProcessed(url);
    
    if (isProcessed) {
        console.log(`✅ الرابط موجود في التخزين المؤقت: ${url}`);
    } else {
        console.log(`❌ الرابط غير موجود في التخزين المؤقت: ${url}`);
    }
    
    return isProcessed;
}

// تصدير الدوال للاستخدام في console
window.noMusicCacheStats = {
    show: showCacheStats,
    clear: clearCacheWithConfirm,
    confirmClear: confirmClearCache,
    addTest: addTestUrl,
    check: checkUrl
};

// عرض رسالة ترحيبية
console.log(`
🎵 no-music Cache Stats Helper
استخدم الدوال التالية في console:

noMusicCacheStats.show()         - عرض إحصائيات التخزين
noMusicCacheStats.check(url)     - التحقق من رابط
noMusicCacheStats.addTest(id)    - إضافة رابط تجريبي
noMusicCacheStats.clear()        - مسح التخزين المؤقت
noMusicCacheStats.confirmClear() - تأكيد المسح
`);
