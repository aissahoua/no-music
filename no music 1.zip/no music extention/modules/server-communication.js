// Server Communication for the no-music extension

/**
 * Manage communication with the local server
 */
class ServerCommunication {
    /**
     * Check if a video has already been processed
     * @param {string} url - The YouTube video URL
     * @returns {Promise<Object>} - Promise resolving to check result
     */
    static async checkProcessed(url) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

            const response = await fetch('http://localhost:5000/check_processed', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: url }),
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('no-music: Error checking processed status:', error);

            // Return standardized error response
            if (error.name === 'AbortError') {
                return { found: false, error: 'timeout' };
            }

            return { found: false, error: error.message };
        }
    }

    /**
     * Send video URL to server for processing
     * @param {string} url - The YouTube video URL
     * @returns {Promise<Object>} - Promise resolving to server response
     */
    static async processVideo(url) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

            const response = await fetch('http://localhost:5000/process_video', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: url, timestamp: new Date().toISOString() }),
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('no-music: Error sending video for processing:', error);

            // Throw standardized error
            if (error.name === 'AbortError') {
                throw new Error('timeout');
            }

            throw error;
        }
    }

    /**
     * Get job status from server
     * @param {string} jobId - The job ID
     * @returns {Promise<Object>} - Promise resolving to job status
     */
    static async getJobStatus(jobId) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

            const response = await fetch(`http://localhost:5000/job_status/${jobId}`, {
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('no-music: Error getting job status:', error);

            // Throw standardized error
            if (error.name === 'AbortError') {
                throw new Error('timeout');
            }

            throw error;
        }
    }

    /**
     * Start periodic progress updates
     * @param {string} jobId - The job ID
     * @param {HTMLVideoElement} video - The video element
     * @param {number} currentTime - Current video time
     * @param {string} audioUrl - The audio URL
     */
    static startProgressUpdates(jobId, video, currentTime, audioUrl) {
        let progressInterval;

        progressInterval = setInterval(() => {
            this.getJobStatus(jobId)
                .then(data => {
                    if (data.error && data.error !== 'timeout') {
                        console.error('no-music: Error getting job status:', data.error);
                        clearInterval(progressInterval);
                        window.LoadingOverlayManager.updateLoadingProgress(0, 'حدث خطأ في الاتصال بالخادم');
                        // Play video in case of error
                        setTimeout(() => {
                            window.LoadingOverlayManager.removeLoadingOverlay();
                            if (video) {
                                video.currentTime = currentTime;
                                video.play();
                                console.log('no-music: Video playing after server error');
                            }
                        }, 2000);
                        return;
                    }

                    // Handle timeout gracefully (retry next interval)
                    if (data.error === 'timeout') {
                        console.warn('no-music: Timeout getting job status, retrying...');
                        return;
                    }

                    console.log(`no-music: Job status - ${data.status}: ${data.progress}%`);

                    // Update progress and status
                    window.LoadingOverlayManager.updateLoadingProgress(data.progress, this.getStatusText(data.status));

                    // If job is completed or error
                    if (data.status === 'completed' || data.status === 'done' || data.status === 'error') {
                        clearInterval(progressInterval);

                        if (data.status === 'completed' || data.status === 'done') {
                            window.LoadingOverlayManager.updateLoadingProgress(100, 'تمت إزالة الموسيقى بنجاح!');

                            // Show toast notification
                            if (window.ToastManager) {
                                window.ToastManager.showToast('تمت معالجة الفيديو بنجاح! استمتع بالمشاهدة بدون موسيقى.');
                            }

                            // Replace audio with processed version
                            window.AudioManager.replaceVideoAudio(video, audioUrl, currentTime);
                        } else {
                            window.LoadingOverlayManager.updateLoadingProgress(0, 'حدث خطأ: ' + (data.error_message || 'غير معروف'));
                            // Play video in case of error
                            setTimeout(() => {
                                window.LoadingOverlayManager.removeLoadingOverlay();
                                if (video) {
                                    video.currentTime = currentTime;
                                    video.play();
                                    console.log('no-music: Video playing after error');
                                }
                            }, 2000);
                        }
                    }
                })
                .catch(error => {
                    console.error('no-music: Connection error with server:', error);
                    clearInterval(progressInterval);
                    window.LoadingOverlayManager.updateLoadingProgress(0, 'حدث خطأ في الاتصال بالخادم');
                    // Play video in case of error
                    setTimeout(() => {
                        window.LoadingOverlayManager.removeLoadingOverlay();
                        if (video) {
                            video.currentTime = currentTime;
                            video.play();
                            console.log('no-music: Video playing after connection error');
                        }
                    }, 2000);
                });
        }, 1000); // Update every second
    }

    /**
     * Helper function to translate job status
     * @param {string} status - The job status
     * @returns {string} - Translated status text
     */
    static getStatusText(status) {
        const statusTexts = {
            'queued': 'في الانتظار...',
            'pending': 'جاري الانتظار...',
            'downloading': 'جاري تحميل الفيديو...',
            'downloaded': 'تم التحميل، جاري فصل الموسيقى...',
            'separating': 'جاري فصل الموسيقى...',
            'processing': 'جاري المعالجة...',
            'merging': 'جاري دمج المسارات...',
            'completed': 'تمت العملية بنجاح!',
            'done': 'تمت العملية بنجاح!',
            'error': 'حدث خطأ في المعالجة'
        };
        return statusTexts[status] || 'جاري المعالجة...';
    }

    /**
     * Fetch list of all processed videos
     * @returns {Promise<Array>} - Promise resolving to array of processed videos
     */
    static async fetchProcessedVideos() {
        try {
            // For now, we'll implement a simple approach
            // In a more advanced implementation, we would create a dedicated endpoint
            // that returns all processed videos
            console.log('no-music: Fetching processed videos list not yet implemented');
            return [];
        } catch (error) {
            console.error('no-music: Error fetching processed videos:', error);
            return [];
        }
    }
}

// Export class
window.ServerCommunication = ServerCommunication;