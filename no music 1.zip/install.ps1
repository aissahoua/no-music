# PowerShell Installer
Write-Host "Checking for Python..."
try {
    $pyVersion = python --version 2>&1
    if ($LASTEXITCODE -ne 0) { throw "Python not found" }
} catch {
    Write-Host "Python is not installed or not in PATH." -ForegroundColor Red
    Write-Host "Please install Python from https://www.python.org/downloads/"
    Pause
    exit
}

if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment..."
    python -m venv .venv
} else {
    Write-Host "Virtual environment already exists."
}

Write-Host "Installing requirements..."
& .venv\Scripts\python.exe -m pip install --upgrade pip
& .venv\Scripts\python.exe -m pip install -r requirements.txt
& .venv\Scripts\python.exe -m pip install onnxruntime

if ($LASTEXITCODE -ne 0) {
    Write-Host "An error occurred during installation." -ForegroundColor Red
    Pause
    exit
}

Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "You can now run 'start.ps1' to start the application."
Pause
